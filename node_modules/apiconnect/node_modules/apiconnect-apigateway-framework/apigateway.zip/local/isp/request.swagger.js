// ***************************************************** {COPYRIGHT-TOP} ***
//* Licensed Materials - Property of IBM
//* 5725-L30, 5725-Z22, 5725-Z63, 5725-U33
//*
//* (C) Copyright IBM Corporation 2016, 2017
//*
//* US Government Users Restricted Rights - Use, duplication, or
//* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
// ********************************************************** {COPYRIGHT-END}**
//
var apim = require('local:///isp/policy/apim.custom.js');
var apimutil = require('local:///isp/apim.util.js');
var headermeta = require('header-metadata');
var jsonx = require('local:///isp/policy/json2jsonx.js');
var servicemeta = require('service-metadata');
var mfpProvidersManager = require('local:///isp/policy/mobileFirst/mfp-providers-manager.js');
var swaggerUtil = require('local:///isp/request.swagger.util.js');
var mfpProviders  = undefined;

var verbose = apim.verbose;

// HEAD request - cache revalidation - return 200 OK
if (servicemeta.protocolMethod === 'HEAD') {
  servicemeta.mpgw.skipBackside = true;
  headermeta.response.statusCode = 200;
  return;
}

// MAIN:
// - fetch API document (Swagger)
//
var target = headermeta.current.get('X-Target-URL');
headermeta.current.remove('X-Target-URL');
headermeta.current.remove('Host');
var headers = headermeta.current.headers;

try {
  apimutil.getDocument(target, headers, function (error, swaggerDoc) {
    if (error)
    {
      apim.console.error("urlopen error: "+JSON.stringify(error));
      throw error;
    }

    mfpProvidersManager.loadMfpProivders(swaggerDoc.catalog, headers, function(error, mfpProvidersResponse){
        if(error){
          // Continue in the regular flow although the error
          apim.console.error("Failed to read MobileFirst providers list");
        }

        mfpProviders = mfpProvidersResponse;
        
        // The /v1/catalogs/:catalogId/apis/:apiId does not return the raw Swagger,
        // so we must find it within its response.
        if (swaggerDoc.document) {
          swaggerDoc = swaggerDoc.document;
        }

        // Add data to the input object and write to the ouput context
        //apim.console.debug("SwaggerDoc: " + JSON.stringify(swaggerDoc));
        var policiesXml = swaggerUtil.translateSwaggerToXML(swaggerDoc, mfpProviders);

        headermeta.current.set('Content-Type', 'application/xml');
        session.output.write(policiesXml);
        require('service-metadata').mpgw.skipBackside = true;
      });
  });
}
catch (error) {
  apim.console.error('request.swagger.js error');
  apim.console.error(error);
  apim.console.error(error.stack);
  headermeta.response.statusCode = 500;
}
