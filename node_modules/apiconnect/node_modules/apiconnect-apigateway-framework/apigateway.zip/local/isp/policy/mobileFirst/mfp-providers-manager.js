// ***************************************************** {COPYRIGHT-TOP} ***
//* Licensed Materials - Property of IBM
//* 5725-L30
//*
//* (C) Copyright IBM Corporation 2016
//*
//* US Government Users Restricted Rights - Use, duplication, or
//* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
// ********************************************************** {COPYRIGHT-END}**
exports.loadMfpProivders = function (catalog, headers, callbackFunc) {
  var catalogUrl;
  var catalogId;
  if (catalog && catalog.url && catalog.id) {
    catalogUrl = catalog.url;
    catalogId = catalog.id;

    var apicUtils = require('local:///isp/policy/mobileFirst/util/mfp-apic-utils');
    var urlopen = require('urlopen');
    var internalWebApiIp = apicUtils.getInternalWebApiIp();
    var internalWebApiPort = apicUtils.getInternalWebApiPort();
    // create similar url http://127.19.10.117:2444/services/v1/catalogs/5787351de4b0f433cdb7184b 
    // replace 'services' with 'mfpProviders'
    var mfpProvidersUrl = 'http://' + internalWebApiIp + ':' + internalWebApiPort + '/mfpProviders/v1/catalogs/' + catalogId;
    let options = {
      target: mfpProvidersUrl,
      method: 'get',
      headers: headers,
      contentType: 'application/x-www-form-urlencoded'
    };

    options.headers["x-mfp-catalog-url"] = catalogUrl;


    urlopen.open(options, function (error, response) {
      if (error) {
        callbackFunc(error, undefined);
      } else {
        var mfpStatusCode = response.statusCode;
        if (mfpStatusCode === 200) {
          response.readAsJSON(function (error, jsonResponse) {
            if (error) {
              callbackFunc(error, undefined);
            } else {
              callbackFunc(error, jsonResponse);
            }
          });
        }
        else { // MFP providers list generator service has fatal error
          callbackFunc(undefined, undefined);
        }
      }
    });
  } else{
    // prevent error in APIC test frameworks (in case the apis.json doesn't include catalog information of id and url) 
    // https://github.ibm.com/apimesh/scrum-edge-gateway/issues/746
    callbackFunc(undefined, undefined);
  }
}


exports.isMobileFirstOauthProvider = isMobileFirstOauthProvider;

function isMobileFirstOauthProvider(assembly) {
  var isMobileFirst = false;
  if (assembly && assembly.execute && assembly.execute.length >= 1) {
    var setVariablePolicy = assembly.execute[0]['set-variable'];
    if (setVariablePolicy && setVariablePolicy.actions) {
      var actions = setVariablePolicy.actions;
      if (actions.length >= 1) {
        var actionsMap = readSetVariableConfigurationFields(actions);
        var mfpOauthType = actionsMap['mfp-oauth-type'];
        isMobileFirst = mfpOauthType !== undefined  && mfpOauthType === true;
      }
    }
  }

  return isMobileFirst;
}

exports.isMobileFirstSecDef = function (mfpProviders, secDefAuthorizationUrl) {
  var isMfpSecDef = false;
  if (mfpProviders) {
    isMfpSecDef = mfpProviders[secDefAuthorizationUrl] != undefined;
  }

  return isMfpSecDef;
}


exports.createMobileFirstSecDefParams = function (mfpProviders, secDefAuthorizationUrl) {
  let mfpOauthProviderInfo = mfpProviders[secDefAuthorizationUrl];
  return mfpOauthProviderInfo;
}

exports.createMfpProviderConfig = function (apisList, products, clusterId) {
  var mfpProvidersList = {};
  var gatewayUrl;
  
  var clusterId = 'id:onpremi:cluster';  // just set the default to that used in onpremi tests
  var gwService;
  if (products && products[0] && products[0].catalog && products[0].catalog['gw-services']) {
      for (var j = 0; j < products[0].catalog['gw-services'].length; j++) {
          var catGWService = products[0].catalog['gw-services'][j];
          if (catGWService.id === clusterId) {
              gwService = catGWService;
          }
      }
  }

  if (gwService !== undefined && gwService['endpoint-url']) {
    gatewayUrl = gwService['endpoint-url'];
  }

  for (let j = 0; j < apisList.length; j++) {
    let swaggerDocument = apisList[j].document;
    let oauth2Config = swaggerDocument['x-ibm-configuration'] ? swaggerDocument['x-ibm-configuration'].oauth2 : undefined;
    if (oauth2Config) {
      var mfpVars = readMfpOauthProviderVariablesFromAssembly(swaggerDocument['x-ibm-configuration'].assembly);
      if (mfpVars) {
        let mfpProviderName = swaggerDocument.info['x-ibm-name'];
        let apiBasePath = swaggerDocument.basePath;
        let authorizePath = '/oauth2/authorize';
        let mfpProviderConfig = {
          "mfpProviderName": mfpProviderName,
          "azserver": mfpVars.azserver,
          "confClientID": mfpVars.confClientID,
          "confClientPass": mfpVars.confClientPass,
          "tlsProfile": mfpVars.tlsProfile
        };

        let secDefAuthorizePathUrl = gatewayUrl + apiBasePath + authorizePath;
        mfpProvidersList[secDefAuthorizePathUrl] = mfpProviderConfig;
      }
    }
  }

  return mfpProvidersList;
}

// TODO be tolerate to different set-variable actions order
function readMfpOauthProviderVariablesFromAssembly(assembly) {
  if (isMobileFirstOauthProvider(assembly)) {
    var actions = assembly.execute[0]['set-variable'].actions;
    if (actions.length === 5) {
      var actionsMap = readSetVariableConfigurationFields(actions);
      var mfpServerUrl = actionsMap['mfp-server-url'];
      var mfpServerContext = actionsMap['mfp-server-context'];
      var mfpClientId = actionsMap['mfp-client-id'];
      var mfpClientSecret = actionsMap['mfp-client-secret'];
      var mfpTlsPrfoile = readMfpTlsProfileFromAssemnly(assembly);
      
      if (mfpServerUrl  && mfpServerContext && mfpClientId && mfpClientSecret) {
        let mfpProviderVars = {
          "azserver": mfpServerUrl + '/' + mfpServerContext,
          "confClientID": mfpClientId,
          "confClientPass": mfpClientSecret,
          "tlsProfile": mfpTlsPrfoile
        };

        return mfpProviderVars;
      }
    }
  }

  return undefined;
}

function readSetVariableConfigurationFields(actions){
  var fields = {};
  
  for (let k = 0; k < actions.length; k++) {
    var fieldName = actions[k].set;
    var fieldValue = actions[k].value;
    fields[fieldName] = fieldValue;
  }
    
  return fields;
}

function readMfpTlsProfileFromAssemnly(assembly) {
  var tlsProfile;;
  if (isMobileFirstOauthProvider(assembly)) {
    var proxyInAssembly = assembly.execute[2];
    if(proxyInAssembly){
      if(proxyInAssembly['proxy'] && proxyInAssembly['proxy']['tls-profile']){
        tlsProfile = proxyInAssembly['proxy']['tls-profile'];
      }
    }
  }

  if (!tlsProfile) {
    tlsProfile = "";
  }

  return tlsProfile;
}
