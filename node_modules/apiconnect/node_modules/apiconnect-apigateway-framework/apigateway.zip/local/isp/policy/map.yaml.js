{
  "info": {
    "version": "1.0.0",
    "x-ibm-name": "map",
    "title": "map"
  },
  "paths": {},
  "schemes": [
    "https"
  ],
  "basePath": "/",
  "securityDefinitions": {
    "Client ID": {
      "in": "header",
      "type": "apiKey",
      "description": "",
      "name": "X-IBM-Client-Id"
    }
  },
  "definitions": {},
  "security": [
    {
      "Client ID": []
    }
  ],
  "swagger": "2.0",
  "x-ibm-configuration": {
    "phase": "realized",
    "testable": true,
    "enforced": true,
    "assembly": {
      "execute": [
        {
          "map": {
            "inputs": [
              {
                "customer": {
                  "definition": null,
                  "value": "message.body.customer"
                }
              },
              {
                "order": {
                  "variable": "message.body.order",
                  "definition": null
                }
              }
            ],
            "title": "Set output",
            "actions": [
              {
                "set": "output.name",
                "from": "customer.firstname"
              },
              {
                "set": "output.shipTo",
                "from": "order.shippingDetails.address.street",
                "value": "$1"
              },
              {
                "set": "output.shipTo",
                "from": "order.shippingDetails.address.street",
                "value": "$1.toUpperCase();"
              }
            ],
            "outputs": [
              {
                "output": {
                  "definition": null,
                  "value": "message.body"
                }
              }
            ]
          }
        }
      ]
    },
    "cors": {
      "enabled": true
    }
  }
}
