// ***************************************************** {COPYRIGHT-TOP} ***
// Licensed Materials - Property of IBM
// 5725-L30, 5725-Z22, 5725-Z63, 5725-U33
//
// (C) Copyright IBM Corporation 2016, 2018
//
// US Government Users Restricted Rights - Use, duplication, or
// disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
// ********************************************************** {COPYRIGHT-END}**

var setvar = require('local:///isp/policy/apim.setvariable.impl.js');
var customimpl = require('local:///isp/policy/apim.custom.impl.js');
var hm = require('header-metadata');

// get the JSON deploy info
var _apimgmt = session.name('_apimgmt');
var json = _apimgmt.getVar('deploy-infoJSON');
var deployInfo = {};
if (json!==undefined) {
  deployInfo = JSON.parse(json);
}


//@@ ================================================================================
//@@ Debug - set it to true to write messages to the console log
var dbglog = console.options({'category':'apiconnect'});
exports.console = dbglog;
exports.debug = session.name('_apimgmt').getVar('policy/debug');

var verbose_level = session.name('_apimgmt').getVar('policy/verbose_level');
exports.verbose = false;
if (verbose_level !== undefined)
{
  if (verbose_level > 0)
  {
    exports.verbose = true;
  }
}
var dbg = exports.verbose;
var debug = exports.debug;

// Setup the APIM_USER_AGENT
var version='5.0'
if (deployInfo && deployInfo.gateway && deployInfo.gateway.build) {
  version  = (deployInfo.gateway.build).substring(0,3);
}
const APIM_USER_AGENT = 'IBM-APIConnect/'+version;

exports.APIM_USER_AGENT = APIM_USER_AGENT;

//WARNING
//This is an internal-use only function.
//Customer authored policies must not attempt to use it.
//Compatibility with previous or future releases will not be maintained.
var getPolicyDetails = function()
{
  var context = session.name('policy');
  var poJSON;
  if (context) {
    poJSON = context.getVar('fw/current-policyJSON');
  }
  if (poJSON === undefined)
  {
    return undefined;
  }
  var policy = undefined;
  try
  {
    policy = JSON.parse(poJSON);
  }
  catch (exception)
  {
    dbglog.error("Error retrieving current policy properties");
    dbglog.error(poJSON);
    throw exception;
  }
  policy.WARNING = "Internal-Use Only";
  //if (exports.debug) {
  //  dbglog.debug('getPolicyDetails: ' + JSON.stringify(poJSON));
  //}
  return policy;
}

exports.getPolicyDetails = getPolicyDetails;

//
// Set Variable and Get Variable
//
exports.setvariable = setvar.setvariable;
exports.getvariable = setvar.getvariable;


//@@ ===================
//@@ Modules
var serviceMetadata = require('service-metadata');

//@@ Retrieve the Assembly Context JSON from var://context/_apimgmt/readContextJSON.
//@@ Parse it into JavaScript and return it entirely or a sub-set.
//@@ Uses recursion to retrieve the contents a specific property in the context JSON
exports.getContext = function(varName)
{
  var contextJSON = session.name('_apimgmt').getVar('readContextJSON');

  // contextJSON can be undefined if this is called from a proxy context
  var context = contextJSON !== undefined ? JSON.parse(contextJSON) : undefined;
  if (context === undefined || varName === undefined) {
    //getMessageInfo(varName);
    return context;
  }
  else {
    var arr = varName.split('.');
    if (arr[0] !== undefined && arr[0] == 'message') {
        return getMessageInfo(varName);
    } else {
        if (arr[0] !== undefined && arr[0] == 'system') {
            return getSystemInfo(varName, context);
        } else {
            if (arr[0] !== undefined && arr[0] == 'request' && (arr[1] == 'parameters' || arr[1] === 'headers')) {
                if(arr.length > 3){
                    var newPropertyName = arr.splice(2).join().replace(",", ".");
                    arr.push(newPropertyName);
                }
            }
            return jsTraverseFn(context, arr, 0);
        }
    }
  }
}
//@@ Attempt to retrieve the API Property for the desired variable name.  If not found, attempt
//@@ to retrieve the Gateway Property from system variable var://system/_apimgmt/<domain-name>/dpext
//@@ If neither found or if the system-metadata module is not available in the running DataPower firmware,
//@@ return undefined.
exports.getGatewayProperty = function(varName, checkAPIProp) {
  var apiProp = undefined;
  if (varName !== undefined) {
    if (checkAPIProp !== false) {
      apiProp = exports.getContext(varName);
    }
    if (apiProp === undefined) {
      try {
        // The varname for getContext would contain a "api.properties." prefix which is not in the property
        // name in the gateway properties, so remove this prefix if present.
        if (varName.slice(0, 15) === 'api.properties.') {
          varName = varName.slice(15);
        }
        var sysm = require('system-metadata');
        var dpext = sysm['_apimgmt'][serviceMetadata.domainName + '/dpext'];
        // only process if the system variable (value is a XML nodelist) was retrieved
        if (dpext !== undefined && dpext.length > 0) {
          // The system variable is a combination of gateway extension and gateway property elements
          // with the following schema
          // <extensions>
          //   <extension ...> 1..n of these elements
          //   <properties>
          //     <property name="name">value</property> 1..n of these elements
          //   </properties>
          // </extensions>

          // get a nodelist of property elements
          var gwproperties = dpext.item(0).getElementsByTagName('property');
          // did we find property elements in the system variable?
          if (gwproperties !== undefined && gwproperties.length > 0) {
            // property elements found, search for the desired one 
            for (var i=0; i<gwproperties.length; i++) {
              var property = gwproperties.item(i);
              var name = property.getAttribute('name');
              // if the desired property, return the element's value
              if (name === varName) {
                return property.textContent;
              }
            }
          }
        }
      } catch (err) {
      // catch is solely to catch the exception where the system-metadata module is not available in
      // the current DataPower version being used.  Thus it will not find a gateway property in this case.
      }
    }
  }
  return apiProp;
}

function getMessageInfo(varName) {
  var varParts = varName.split('.');
  var retVal = undefined;
  if( varParts[0] === 'message' ){
    switch(varParts[1]){
      case 'headers':
        if (varParts[2]){
          //1. Grab a specific header
          retVal = hm.current.get(varParts[2]);
        } else {
          retVal = hm.current.get();
        }
        break;
      case 'status':
        switch(varParts[2]) {
          case 'code':
            retVal =  hm.response.statusCode;
            break;
          case 'reason':
            retVal = hm.response.reasonPhrase || '';
            break;
        }
        break;
      case 'body':
        //readInput(function(error, data) {
        //    if (!error) {
        //        retVal = data;
        //    }
        //});
        break;
      default:
        //Do nothing..  Maybe Log an error.
        break;
    }
  }
  return retVal;
}


function getSystemInfo(varName, context) {
    var varParts = varName.split('.');
    var retVal = undefined;
    if( varParts[0] === 'system' ){
        switch(varParts[1]){
            case 'datetime':
                retVal = getDateTime();
                break;
            case 'time':
                if (varParts[2]===undefined) {
                    retVal = getTime();
                } else {
                    switch(varParts[2]){
                        case 'hour':
                            retVal = getTimeHour();
                            break;
                        case 'minute':
                            retVal = getTimeMinute();
                            break;
                        case 'seconds':
                            retVal = getTimeSeconds();
                            break;
                    }
                }
                break;
            case 'date':
                if (varParts[2]===undefined) {
                    retVal = getDate();
                } else {
                    switch(varParts[2]){
                        case 'day-of-week':
                            retVal = getDateDayOfWeek();
                            break;
                        case 'day-of-month':
                            retVal = getDateDayOfMonth();
                            break;
                        case 'month':
                            retVal = getDateMonth();
                            break;
                        case 'year':
                            retVal = getDateYear();
                            break;
                    }
                }
                break;
            case 'timezone':
                retVal = jsTraverseFn(context, varParts, 0);
                break;
        }
    }
    return retVal;
}

var options = {};
// defines/defaults the datetime, date, and time format
options.datetimeFormat = options.datetimeFormat || 'YYYY-MM-DDTHH:mm:ss';
options.timezoneFormat = options.timezoneFormat || 'Z';

function getTime() {
    var localTime = new Date().toTimeString();
    var timeIndex = localTime.indexOf(' ');
    return (localTime.substr(0,timeIndex));
}

function getDate() {
    //logger.debug('getDateTime()');
    return getDateYear() + "-" + getDateMonth(true) + "-" + getDateDayOfMonth(true);
}

function getDateTime() {
    //logger.debug('getDateTime()');
    var getCurrentTime = getTime();
    var getCurrentDate = getDateYear() + "-" + getDateMonth(true) + "-" + getDateDayOfMonth(true);
    return getCurrentDate + "T" + getCurrentTime;
}

function getTimeHour() {
    //logger.debug('getTimeHour()');
    return (new Date()).getHours();
}

function getTimeMinute() {
    //logger.debug('getTimeMinute()');
    return (new Date()).getMinutes();
}

function getTimeSeconds() {
    //logger.debug('getTimeSeconds()');
    return (new Date()).getSeconds();
}

function getDateDayOfWeek() {
    //logger.debug('getDateDayOfWeek()');
    var dow = (new Date()).getDay();
    if (dow!==undefined && dow === 0) {
        dow = 7;
    }
    return dow;
}

function getDateDayOfMonth(isString) {
    //logger.debug('getDateDayOfMonth()');
   var result = new Date().getDate();
    if(isString){
        result = ('0' + result).slice(-2);
    }   
    return result;
   }

function getDateMonth(isString) {
    //logger.debug('getDateMonth()');
    var result = (new Date().getMonth())+1;
    if(isString){
        result = ('0' + result.toString()).slice(-2);
    }
    return result;
    
}

function getDateYear() {
    //logger.debug('getDateYear()');
    return (new Date()).getFullYear();
}

function returnValue (error, value) {
    if (!error) {
        return value
    } else {
        return undefined;
    }
}

//@@ Reads the current running policy from var://context/policy/fw/current-policyJSON
//@@ Parse it into JavaScript and return the entire set of policy properties or the requested one @propertyName
//@@ Uses recursion to retrieve the a property value for an specifically given property name
exports.getPolicyProperty = function(propertyName, decode, doResolve, options)
{
  var asEntered = exports.getPolicyPropertyAsEntered(propertyName);
  var policy = getPolicyDetails();

  // if the policy didn't provide a doResolve boolean and this policy has source code, set the boolean
  // based on a API property toggle, with the default of the property not being defined as false.
  if (doResolve === undefined &&
      (policy['@type'] === 'map' ||
       policy['@type'] === 'gatewayscript' ||
       policy['@type'] === 'xslt')) {
    doResolve = (exports.getGatewayProperty('api.properties.x-ibm-gateway-sourcecode-resolve-apic-variables', true) !== 'false');
  }

  // only resolve policy variables based upon what the policy requested or in the case of a policy with source
  // code, based on the API toggle.
  if (doResolve === undefined || doResolve) {
    var leaveUndefined = (policy['@type'] === 'map') || (policy['@type'] === 'gatewayscript') || (policy['@type'] === 'xslt');
    return customimpl.resolveVariablesInObject(asEntered, leaveUndefined, function(varname) {
      if (dbg) {
        dbglog.debug('resolveCallback[' + varname + ']' + ' ' + JSON.stringify(setvar.getvariable(varname, decode, options)));
      }
      return setvar.getvariable(varname, decode, options);
    });
  } else {
    return asEntered;
  }
}

exports.getPolicyPropertyAsEntered = function(propertyName) {
  var policy = getPolicyDetails();
  if (propertyName === undefined)
  {
    return policy.properties;
  }
  else
  {
    var array = propertyName.split('.');
    return jsTraverseFn(policy.properties, array, 0);
  }
}

//@@ Traverses a JS object looking for a property value for
//@@ a property string named "x.y.z"
//@@ (poor man's version of eval)
var jsTraverseFn = function(ctx,arr,idx)
{
  if (dbg) {
    dbglog.debug('fn: arr=' + arr + '; idx=' + idx);
  }
  var propertyname = arr[idx];
  if (propertyname === undefined)
  {
    return ctx;
  }
  else if (ctx === undefined)
  {
    return undefined;
  }
  else
  {
    return jsTraverseFn(ctx[propertyname],arr,idx+1);
  }
}

function selectInput(context)
{
  if (context === undefined) {
    var _apimgmt = session.name('_apimgmt');
    var mediaType = _apimgmt.getVar('policy-output-mediaType');
    var usePolicyOutput = _apimgmt.getVar('use-policy-output');
    if (usePolicyOutput !== 'true') //mediaType === undefined || mediaType === '')
      context = 'INPUT';
    else
      context = 'policy-output';
    if (dbg) dbglog.debug('readInputAsBuffer: mediaType=' + mediaType + ' usePolicyOutput=' + usePolicyOutput + ' ' + typeof usePolicyOutput);
  }
  if (dbg) dbglog.debug('readInputAsBuffer: context=' + context);

  return session.name(context);
}

/**
 * Reads logical input or the given context
 * @param callback            invoked at completion as f(error, data)
 * @param context             optional, specific input source
 */
exports.readInputAsBuffer = function(callback, context)
{
  var input = selectInput(context);
  if (!input) {
    callback(new Error('Undefined context: ' + context), undefined);
  } else {
    input.readAsBuffer(function (error, buffer) {
      callback(error, buffer);
    });
  }
}

/**
 * Reads logical input or the given context
 * @param callback            invoked at completion as f(error, data)
 * @param context             optional, specific input source
 */
exports.readInputAsJSON = function(callback, context)
{
  var input = selectInput(context);
  if (!input) {
    callback(new Error('Undefined context: ' + context), undefined);
  } else {
    input.readAsBuffer(function (error, buffer) {
      if (!error) {
        var json = undefined;
        var sjson = buffer.toString();
        if (sjson.length > 0) {
          try {
            json = JSON.parse(sjson);
            // only update the policy output mediaType if that context variable has not been
            // set before or if this is updating the policy-output context
            var mediaType = session.name('_apimgmt').getVar('policy-output-mediaType');
            if (mediaType === undefined || mediaType === '' || context === 'policy-output') {
              session.name('_apimgmt').setVar('policy-output-mediaType','application/json');
            }
          }
          catch (err) {
            error = new Error('The JSON document is not valid. ' + err.errorMessage);
          }
        }
      }
      callback(error, json);
    });
  }
}

/**
 * Reads logical input or the given context
 * @param callback            invoked at completion as f(error, data)
 * @param context             optional, specific input source
 */
exports.readInputAsXML = function(callback, context)
{
  var input = selectInput(context);
  if (!input) {
    callback(new Error('Undefined context: ' + context), undefined);
  } else {
    input.readAsXML(function (error, buffer) {
      callback(error, buffer);
    });
  }
}

/**
 * Reads logical input or the given context+mediatype
 * @param callback            invoked at completion as f(error, data)
 * @param context             optional, specific input source
 * @param mediaType           optional, but required if context given
 */
exports.readInput = function(callback, context, mediaType)
{
  if (context) {
    if (!mediaType) {
      callback(new Error('mediaType is required when context is given'), undefined);
      return;
    }
  }
  else {
    var _apimgmt = session.name('_apimgmt');
    var poHasOutput = _apimgmt.getVar('use-policy-output');
    if (dbg) dbglog.debug('readInput: poHasOutput=' + poHasOutput);
    if (poHasOutput=='false' || !poHasOutput) {
       mediaType = hm.current.get('Content-Type');
    }
    else {
       mediaType = _apimgmt.getVar('policy-output-mediaType');
    }
  }
  if (dbg) dbglog.debug('readInput: mediaType=' + mediaType);
  if (exports.isJSON(mediaType)) {
    exports.readInputAsJSON(callback, context);
  }
  else if (exports.isXML(mediaType)) {
    exports.readInputAsXML(callback, context);
  }
  else {
    exports.readInputAsBuffer(callback, context);
  }
}


/**
 * Reports an error. Interrupts the execution, throwing an exception
 * @param name                the name of this exception
 * @param httpCode            optional, suggested HTTP Code for Response
 * @param httpReasonPhrase    optional, suggested HTTP Reason Phrase for Response
 * @param message             optional, error message details
 * @param ignorecatch         optional, true|false (default)  exception is from a security policy
 *                                      or some other one which will not be caught in a catch
 */
exports.error = function(name,httpCode,httpReasonPhrase,message,ignorecatch)
{
  var policyDetails = getPolicyDetails(); //internal-use only
  var policySession = session.name('policy');
  var _ignorecatch  = false;
  if (ignorecatch != undefined)
      _ignorecatch = ignorecatch;

  var excObject = {
      name: name,
      scope: policyDetails['@depth'],
      source: policyDetails['@annotated-position'],
      httpCode: httpCode,
      httpReasonPhrase: httpReasonPhrase,
      message: message,
      ignorecatch: _ignorecatch
  };
  policySession.setVar('fw/next-policy', '_EXCEPTION_');
  policySession.setVar('fw/exception', excObject);
  session.name('policy').setVar('fw/next-policy', '_EXCEPTION_');
  session.name('policy').setVar('flow/exception', excObject);

  var prefix = 'apim.custom.js: error: ';
  if (dbg) {
    dbglog.debug(prefix + name);
    dbglog.debug(prefix + 'http: ' + httpCode + ' ' + httpReasonPhrase);
    dbglog.debug(prefix + 'message: ' + message);
    dbglog.debug(prefix + 'ignore catch: ' + _ignorecatch);
  }
}

/**
 *
 */
exports.output = function(mediaType) {
  var _apimgmt = session.name('_apimgmt');
  if (mediaType) {
    _apimgmt.setVar('policy-output-mediaType',mediaType);
  }
  _apimgmt.setVar('policy-output-set','true');
  _apimgmt.setVar('content-type-override','');
}

exports.isJSON = function(contenttype) {
	var response = false;

	if (contenttype && contenttype.length > 0) {
		contenttype = contenttype.toLowerCase();
		var exp1 = /^text\/.+\+json$/;
		var exp2 = /^application\/.+\+json$/;
		if (contenttype.indexOf('application/json')>=0  ||
			contenttype.indexOf('text/json')>=0 ||
			contenttype == 'application/json'  ||
			contenttype == 'text/json' ||
			exp1.test(contenttype) ||
			exp2.test(contenttype) || contenttype.indexOf("json") >=0 )
		{
			response = true;
		}
	}
	return response;
}

exports.isXML = function(contenttype) {
	var response = false;

	if (contenttype && contenttype.length > 0) {
		contenttype = contenttype.toLowerCase();
		var exp1 = /^text\/.+\+xml$/;
		var exp2 = /^application\/.+\+xml$/;
		if (contenttype.indexOf('application/xml')>=0  ||
			contenttype.indexOf('text/xml')>=0 ||
			contenttype == 'application/xml'  ||
			contenttype == 'text/xml' ||
			exp1.test(contenttype) ||
			exp2.test(contenttype) || contenttype.indexOf("xml") >=0)
		{
			response = true;
		}
	}
	return response;
}

exports.getTLSProfileObjName = function(sslProfileNameOrId)
{
  if (!sslProfileNameOrId || sslProfileNameOrId.length === 0) {
    if (dbg) dbglog.debug('getTLSProfileObjName: returning default profile.');
    return 'client:api-sslcli-all';
  }

  if (sslProfileNameOrId.indexOf('client:') === 0){
      return sslProfileNameOrId;
  }

  // this is a no-op if default profile is requested
  // except, return with prefix
  if (sslProfileNameOrId === 'api-sslcli-all') {
    return 'client:' + sslProfileNameOrId;
  }

  var _apimgmt = session.name('_apimgmt');
  if (!_apimgmt) {
    dbglog.error('getTLSProfileObjName: apimgmt session missing.');
    return undefined;
  }

  var tlsMap = _apimgmt.getVariable('gateway-xml');
  if (!tlsMap) {
    dbglog.error('getTLSProfileObjName: missing gateway-xml.')
    return undefined;
  }

  tlsMap = tlsMap.item(0).getElementsByTagName("tls-profiles").item(0).lastChild.textContent;
  if (!tlsMap === undefined || tlsMap.length === 0) {
    dblog.error('getTLSProfileObjName: cannot find tls-profile element.');
    return undefined;
  }

  try {
    tlsMap = JSON.parse(tlsMap);
    var sslProfileObjectName = undefined;
    var tp = _apimgmt.getVariable('tenant-policy');
    if (tp){
      var orgName = tp.item(0).getAttribute('orgName');
      if (orgName){
        var orgTlsProfiles = tlsMap[orgName];
        if (orgTlsProfiles){
          sslProfileObjectName =  orgTlsProfiles[sslProfileNameOrId];
          if (!sslProfileObjectName && sslProfileNameOrId.startsWith(orgName + '-')) {
            sslProfileObjectName =  orgTlsProfiles[sslProfileNameOrId.substring(orgName.length+1)];
          }
        }
      }
    } else {
      dblog.error('getTLSProfileObjName: error reading tenant policy.');
    }

    if (!sslProfileObjectName) {
      sslProfileObjectName = tlsMap["cmc"];
      if (sslProfileObjectName){
        sslProfileObjectName = sslProfileObjectName[sslProfileNameOrId];
      }
    }

    if (!sslProfileObjectName) {
      return undefined;
    }

    return 'client:' + sslProfileObjectName;
  }
  catch (err) {
    dbglog.error(err.stack);
    return undefined;
  }
}

exports.getManagedObject = customimpl.getManagedObject;
exports.getManagedObjectName = customimpl.getManagedObject;

exports.getManagedObjectValue = function(type, object, property) {
  var options = {name: object, property: property};
  return customimpl.getManagedObject(options,  type);
}

exports.getManagedObjectDPName = function(type, object) {
  var options = {name: object,  asObject: 'true'};
  return customimpl.getManagedObject(options,  type);
}

exports.getSwaggerDefinition = function(name, definitionOnly) {
  var swaggerDoc = exports.getContext('api.document');
  var result;
  if (swaggerDoc) {
    result = customimpl.getSwaggerDefinition(swaggerDoc, name, undefined, definitionOnly);
  }
  else {
    dbglog.error('getSwaggerDefinition: failed to retrieve Swagger from context');
  }
  return result;
}

exports.util = require('local:///isp/policy/apim.functions.js');

// only export the required mapping v4 legacy function if indeed this is a map policy requiring this module
var policydetails = getPolicyDetails();
if (policydetails && policydetails['@type'] === 'map') {
  exports.v4 = require('local:///isp/policy/apim.map.legacy_functions.js');
}
//***************************************************************************
//**********  apim analytics debug functions   ******************************
//***************************************************************************
exports.writeAnalyticsDebug = function(analyticsPolicyDebug)
{
    if (debug) {
        if (dbg) dbglog.debug("analyticDebug: writeAnalyticsDebug: entry");
        var policyDetails = getPolicyDetails();
        analyticsPolicyDebug.name = (policyDetails['@name'] !== undefined ? policyDetails['@name'] : '');

        // Convert the data to jsonx
        var analyticsPolicyDebugJSONXStr = require('local:///isp/policy/json2jsonx.js').transform(analyticsPolicyDebug, JSON.parse('{"excludeNamespace": false, "jsonxPrefix": "json"}'));

        var analyticsPolicyDebugJSONXNode = XML.parse(analyticsPolicyDebugJSONXStr);
        var options = { "location" : "local:///isp/policy/apim.concatenate.debug.context.xsl", "xmldom" : analyticsPolicyDebugJSONXNode

        };
        require('transform').xslt(options, function(error, nodelist, abortinfo) {
        });
        if (dbg) dbglog.debug("analyticDebug: writeAnalyticsDebug: exit");
    }
}

exports.addDataForAnalytics = function(baseObj, withData, toName, withName) {
    if (debug) {
        if (dbg) dbglog.debug("analyticDebug: addDataForAnalytics: entry");
        if (baseObj === undefined) {
            baseObj = {};
        }
        var toObj;
        if (toName !== undefined) {
            if (toName.indexOf('.') > 0) {
                var objNames = toName.split('.');
                toObj = baseObj;
                for (var i = 0; i < objNames.length; i++) {
                    if (toObj[objNames[i]] === undefined) {
                        toObj[objNames[i]] = {};
                        toObj = toObj[objNames[i]];
                    }
                }
            } else {
                toObj = baseObj[toName];
            }
            // if the object doesnt exist we need to create it first
            if (withName === undefined) {
                // there is no withName specified so we need to add to the toName
                traverseAndAdd(toObj, withData);
            } else {
                if (toObj[withName] === undefined) {
                    toObj[withName] = withData;
                } else {
                    traverseAndAdd(toObj[withName], withData);
                }
            }
        } else {
            // If the toName is not defined then we need to add to the top level object
            if (withName === undefined) {
                // there is no withName specified so we need to add to the toName
                traverseAndAdd(toObj, withData);
            } else {
                if (toObj[withName] === undefined) {
                    toObj[withName] = withData;
                } else {
                    traverseAndAdd(toObj[withName], withData);
                }
            }
        }

        if (dbg) dbglog.debug("analyticDebug: addDataForAnalytics: exit: output = [" + JSON.stringify(baseObj) + "]");
    }
    return baseObj;
}

exports.generateInputDataForAnalytics = function(body, headers, contentType, useBody) {
    var input;
    if (debug) {
        if (dbg) dbglog.debug("analyticDebug: generateInputDataForAnalytics: entry");
        var option = { omitXmlDeclaration : true };
        var tempInput = {};
        var inputSet = false;

        if (body !== undefined) {
            if (contentType !== undefined) {
                var bodyVar = {};
                if (exports.isJSON(contentType)) {
                    if ((typeof body == 'object' || typeof body == 'array') && Object.keys(body).length > 0) {
                        var jsonBodyStr = JSON.stringify(body); // TEMPORARY stringify the  body
                        bodyVar = jsonBodyStr;
                    } else {
                        bodyVar = body;
                    }
                } else if (exports.isXML(contentType)) {
                    var xmlBodyStr;
                    if (typeof body !== "string") {
                        if (body.length>0) {
                            xmlBodyStr = XML.stringify(option, body);
                        } else {
                            xmlBodyStr = '';
                        }
                    } else {
                        xmlBodyStr = body;
                    }
                    bodyVar = xmlBodyStr;
                } else {
                    bodyVar = "Non JSON or XML Data";
                }
                if (useBody !== undefined && useBody === true) {
                    tempInput.body = bodyVar;
                } else {
                    tempInput = bodyVar;
                }
                inputSet = true;
            }
        }

        if (headers !== undefined) {
            tempInput.headers = headers;
            inputSet = true;
        }

        if (inputSet) {
            input = tempInput;
        }

        if (dbg) dbglog.debug("analyticDebug: getInputDataForAnalytics: exit: input = [" + JSON.stringify(input) + "]");
    }
    return input;
}

exports.generateOutputDataForAnalytics = function(body, headers, contentType, response, useBody) {
    var output;
    if (debug) {
        if (dbg) dbglog.debug("analyticDebug: generateOutputDataForAnalytics: entry");
        var option = { omitXmlDeclaration : true };
        var tempOutput = {};
        var outputSet = false;
        if (body !== undefined) {
            var bodyVar = {};
            if (exports.isJSON(contentType)) {
                if ((typeof body == 'object' || typeof body == 'array') && Object.keys(body).length > 0) {
                    var jsonBodyStr = JSON.stringify(body); // TEMPORARY stringify the  body
                    bodyVar = jsonBodyStr;
                } else {
                    bodyVar = body;
                }
            } else if (exports.isXML(contentType)) {
                var xmlBodyStr;
                if (typeof body === "string") {
                    xmlBodyStr = body;
                } else {
                    if (body.length>0) {
                        xmlBodyStr = XML.stringify(option, body);
                    } else {
                        xmlBodyStr = '';
                    }
                }
                if (xmlBodyStr.length >= 0) {
                    bodyVar = xmlBodyStr;
                }
            } else {
                bodyVar = 'Non JSON or XML data';
            }
            if (useBody !== undefined && useBody === true) {
                tempOutput.body = bodyVar;
            } else {
                tempOutput = bodyVar;
            }
            outputSet = true;
        }

        if (headers !== undefined) {
            tempOutput.headers = headers;
            outputSet = true;
        }

        if (response !== undefined) {
            tempOutput.status = {};
            if (response.statusCode) tempOutput.status.code = response.statusCode;
            if (response.reasonPhrase) tempOutput.status.reason = String(response.reasonPhrase);
            if (response.soapError) tempOutput.status.soapError = response.soapError;
            if (response.connectionError) tempOutput.status.connectionError = response.connectionError;
            if (response.operationError) tempOutput.status.operationError = response.operationError;
            outputSet = true;
        }

        if (outputSet) {
            output = tempOutput;
        }

        if (dbg) dbglog.debug("analyticDebug: generateOutputDataForAnalytics: exit: output = [" + JSON.stringify(output) + "]");
    }
    return output;
}

exports.addPolicyPropertiesToData = function(analyticsData) {
    if (analyticsData===undefined) { analyticsData = {}; }
    var policyProperties = exports.getPolicyPropertyAsEntered();
    if (policyProperties!==undefined) {
        analyticsData.properties = policyProperties;
    }
    return analyticsData;
}

exports.addAnalyticsInputToData = function(analyticsData, analyticsInput, name) {
    if (debug) {
        if (dbg) dbglog.debug("analyticDebug: addAnalyticsInputToData: entry: analyticsData = [" + JSON.stringify(analyticsData) + "]");
        if (analyticsData===undefined) { analyticsData = {}; }
        if (analyticsData.input===undefined) {
            analyticsData.input={};
        }
        var location = 'request';
        if (!(name === undefined || name == null || name.length == 0)) {
            location=name;
        }
        analyticsData.input[location]=analyticsInput;
        if (dbg) dbglog.debug("analyticDebug: addAnalyticsInputToData: exit: analyticsData = [" + JSON.stringify(analyticsData) + "]");
    }
    return analyticsData;
}

exports.addAnalyticsOutputToData = function(analyticsData, analyticsOutput, name) {
    if (debug) {
        if (dbg) dbglog.debug("analyticDebug: addAnalyticsOutputToData: entry: analyticsData = [" + JSON.stringify(analyticsData) + "]");
        if (analyticsData===undefined) { analyticsData = {}; }
        if (analyticsData.output===undefined) {
            analyticsData.output={};
        }
        var location = 'message';
        if (!(name === undefined || name == null || name.length == 0)) {
            location=name;
        }
        analyticsData.output[location]=analyticsOutput;
        if (dbg) dbglog.debug("analyticDebug: addAnalyticsOutputToData: exit: analyticsData = [" + JSON.stringify(analyticsData) + "]");
    }
    return analyticsData;
}

exports.addAnalyticsOtherToData = function(analyticsData, analyticsOther, name) {
    if (debug) {
        if (dbg) dbglog.debug("analyticDebug: addAnalyticsOtherToData: entry: analyticsData = [" + JSON.stringify(analyticsData) + "]");
        if (analyticsData===undefined) { analyticsData = {}; }
        if (name===undefined) {
            // We need to add the data to the base analyticsData object
            traverseAndAdd(analyticsData, analyticsOther);
        } else {
            if (analyticsData[name]===undefined) {
                analyticsData[name] = analyticsOther;
            } else {
                // Need to add data to the existing object defined by 'name' variable
                traverseAndAdd(analyticsData[name], analyticsOther);
            }
        }
        if (dbg) dbglog.debug("analyticDebug: addAnalyticsOtherToData: exit: analyticsData = [" + JSON.stringify(analyticsData) + "]");
    }
    return analyticsData;
}

function traverseAndAdd(analyticsData, analyticsOther) {
    if (typeof analyticsData === "object") {
        if ((typeof analyticsOther === "object") && (analyticsOther !== null)) {
            // We have a json object
            for ( var key in analyticsOther) {
              if (analyticsOther.hasOwnProperty(key)) {
                var value = analyticsOther[key];
                analyticsData[key]=value;
              }
            }
        } else if ((typeof analyticsOther === "array") && (analyticsOther !== null)) {
            // We have a json array
            analyticsData["array"]=analyticsOther;
        } else {
            // We shouldn't get here as we only support JSON array or object
        }
    } else if (typeof analyticsData === "array") {
        analyticsData.push(analyticsOther);
    }
}

exports.determineMediaType = function(headers) {
    var sm = require('service-metadata');
    if (headers) {
      var keys = Object.keys(headers);
      for (var i = 0;  i < keys.length; i++) {
        var header = keys[i];
        if (header && header.toLowerCase() == 'content-type' && headers[header]) {
          return headers[header];
        }
      }
    }

    var originalContentType = sm.getVar('var://service/original-content-type');
    var mediaType;
    if (session.name('_apimgmt').getVar('use-policy-output') === 'true') {
      mediaType = session.name('_apimgmt').getVar('policy-output-mediaType');
    } else {
      mediaType = originalContentType;
    }
    var override = session.name('_apimgmt').getVar('content-type-override');
    if (dbg) {
      dbglog.debug("determineMediaType: Original contenttype is [" + originalContentType + "]");
      dbglog.debug("determineMediaType: Policy output mediatype is [" + mediaType + "]");
      dbglog.debug("determineMediaType: Policy content-type override is [" + override + "]");
    }
    if (override !== undefined && override !== '') {
      mediaType = override;
    } else {
      if (mediaType === undefined || mediaType === '') {
          mediaType = originalContentType;
      }
    }
    return mediaType;
}
