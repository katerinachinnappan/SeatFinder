// ***************************************************** {COPYRIGHT-TOP} ***
//* Licensed Materials - Property of IBM
//* 5725-L30, 5725-Z22, 5725-Z63, 5725-U33
//*
//* (C) Copyright IBM Corporation 2016, 2017
//*
//* US Government Users Restricted Rights - Use, duplication, or
//* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
// ********************************************************** {COPYRIGHT-END}**
//
var hm = require('header-metadata');

var logPrefix = 'apim.error.response: ';

var analyticsData = session.name('_apimgmt').getVar('proxy/anadebug');
if (analyticsData!==undefined) {
    var apim = require('local:///isp/policy/apim.custom.js');
    var dbglog = apim.console;
    var verbose = apim.verbose;

    var response = {};
    var headers = hm.current.get();
    var responseCode = session.name('api').getVar('error-protocol-response') || 500;
    var responsePhrase = session.name('api').getVar('error-protocol-reason-phrase') || 'Internal Server Error';

    response.statusCode = responseCode;
    response.reasonPhrase = responsePhrase;
    
    var analyticsOther = {};
    analyticsOther.endpoint = apim.getPolicyProperty('target-url'); 
    if (responseCode!==undefined && String(responseCode).indexOf('20') == 0) {
        analyticsOther.result = 'OK';
    } else {
        analyticsOther.result = 'Error';
    }
    
    analyticsData = apim.addAnalyticsOutputToData(analyticsData, apim.generateOutputDataForAnalytics(undefined, headers, headers['Content-Type'], response, false));
    analyticsData = apim.addAnalyticsOtherToData(analyticsData, analyticsOther);
    apim.writeAnalyticsDebug(analyticsData);
}
