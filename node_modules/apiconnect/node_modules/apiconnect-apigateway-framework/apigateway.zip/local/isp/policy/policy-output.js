// ***************************************************** {COPYRIGHT-TOP} ***
// Licensed Materials - Property of IBM
// 5725-L30, 5725-Z22, 5725-Z63, 5725-U33
//
// (C) Copyright IBM Corporation 2016, 2017
//
// US Government Users Restricted Rights - Use, duplication, or
// disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
// ********************************************************** {COPYRIGHT-END}**

var _apimgmt = session.name("_apimgmt");
var apim = require("local:///isp/policy/apim.custom.js");
var dbglog = apim.console;
var policyOutput = session.name("policy-output")  || session.createContext('policy-output');
var mediaType = _apimgmt.getVar('policy-output-mediaType');

    session.name("policy-output-temp").readAsBuffer(function(error, buffer) {
      if (error){
        dbglog.error("Policy-output.js readAsBuffer error : " + "[" + error.errorMessage + "]");
      }else{
        if (apim.isJSON(mediaType)){
          var jsonOut = JSON.parse(buffer);
          policyOutput.write(jsonOut);
        } else if (apim.isXML(mediaType)){
            var xmlOut = XML.parse(buffer);
            policyOutput.write(xmlOut);
        } else{
            policyOutput.write(buffer);
        }
      }
    }
  );