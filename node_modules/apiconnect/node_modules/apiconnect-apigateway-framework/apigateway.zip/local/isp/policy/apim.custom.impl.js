// ***************************************************** {COPYRIGHT-TOP} ***
// Licensed Materials - Property of IBM
// 5725-L30, 5725-Z22, 5725-Z63, 5725-U33
//
// (C) Copyright IBM Corporation 2016, 2018
//
// US Government Users Restricted Rights - Use, duplication, or
// disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
// ********************************************************** {COPYRIGHT-END}**
//var fs = require('fs'); // leave this commented in the code, uncomment for any instrumented testing
var dbg = false;
var context = session.name('_apimgmt');
if (context !== undefined) {
  var verbose_level = context.getVar('policy/verbose_level');
  if (verbose_level !== undefined)
  {
    if (verbose_level > 0)
    {
      dbg = true;
    }
  }
}
const dbglog = console.options({'category':'apiconnect'});
const SCHEMA_CIRCULAR_REFERENCE_MAX = 5;

// ****************************************************************************
// Find and Replace context variables and parameters
// - context variables - $(variable)
// - parameters - {parameter}
// @param input - the original input, e.g. 'https://$(host)/foo'
// @param callbackToResolve - a function that will be called to resolve
//        the value of a provided variable, e.g. callbackToResolve('host')
function resolveVariables(input,leaveUndefined,callbackToResolve) {
  if (dbg) dbglog.debug('resolveVariables: ' + input);
  var regex;
  // going to look for $(variables)... if we are matching $(request.headers)
  // the resulting replacement may be an object vs string
  if (typeof input === 'string' && input.indexOf('$(') > -1) {
    regex = /(\$\([a-zA-Z\-\.\_\:0-9\+]+\))/g;
    input = matchAndReplace(input,regex,callbackToResolve,false,leaveUndefined);
  }
  // going to look for {parameters}... before searching for params, make
  // sure `input` is still a string and not a replaced object.
  if (typeof input === 'string' && input.indexOf('{') > -1) {
    regex = /(\{[a-zA-Z\-\.\_0-9\+]+\})/g;
    input = matchAndReplace(input,regex,callbackToResolve,true,leaveUndefined);
  }
  return input;
}

function matchAndReplace(input,regex,callbackToResolve,isParam,leaveUndefined) {
  if (dbg) dbglog.debug('matchAndReplace: ' + input);
  var loopmax = 60;
  var match = regex.exec(input);
  var varname, value;
  while (match !== null && loopmax-->0) {
    if (isParam) {
      // Check for string literal.
      if(match.index > 0 && input.charAt(match.index - 1) === '$')
      {
        continue;
      }

      varname = match[1].substring(1,match[1].length-1); // remove {}
      if (isNaN(varname)) {
        value = callbackToResolve('request.parameters.' + varname);
      } else {
        match = regex.exec(input);
        continue;
      }
    }
    else {
      varname = match[1].substring(2,match[1].length-1); // remove $()
      value = callbackToResolve(varname);
    }
    if (value !== undefined || !leaveUndefined) { // need to explicity check for not undefined as we don want to catch '' (empty string)
      if (value === undefined) {
        value = '';
      }
      input = replaceValues(input,match[1],value);
      regex.lastIndex -= match[1].length;
    }
    match = regex.exec(input);
  }
  return input;
}

function replaceValues(input,match,value) {
  if (input === match) { // full match, replace input variable
    input = value;
  }
  else if (input.indexOf(match) > -1)
  {
    // '$' has special meaning in the replace function (for example '$$' in the new value stands for '$')
    // Therefore, we convert '$' in the value to '$$' to make the '$' have its literal meaning in the input replace
    if (typeof value === "string") {
      value = value.replace(/\$/g,'$$$$');
    }

    input = input.replace(match,value);
    input = replaceValues(input,match,value);
  }
  return input;
}

// exports.resolveVariables = resolveVariables;

// ****************************************************************************
// Find and Replace context variables and parameters in the values of a
// JavaScript object or array
function resolveVariablesInObject(object,leaveUndefined,callbackToResolve) {
  if (dbg) dbglog.debug('resolveVariablesInObject: ' + typeof object + ' ' + JSON.stringify(object));
  if (typeof object === 'object') {
    var result = object;
    for (var i in object) {
      if (object.hasOwnProperty(i)) {
        result[i] = resolveVariablesInObject(object[i],leaveUndefined,callbackToResolve);
      }
    }
    return result;
  }
  else {
    return resolveVariables(object,leaveUndefined,callbackToResolve);
  }
}

exports.resolveVariablesInObject = resolveVariablesInObject;

//****************************************************************************
//Fetches a definition from the Swagger document in context.
//If this definition defines other definitions, it will traverse them
//resolving them into a JavaScript object.
//
//Logic will only traverse references within the same Swagger document.
function getSwaggerDefinition(swaggerDoc,defName,processedReferences,definitionOnly,foundMap) {
  var performanceToggle = (swaggerDoc &&
                           swaggerDoc['x-ibm-configuration'] &&
                           swaggerDoc['x-ibm-configuration'].properties &&
                           swaggerDoc['x-ibm-configuration'].properties['x-ibm-gateway-optimize-schema-definition']?
                           swaggerDoc['x-ibm-configuration'].properties['x-ibm-gateway-optimize-schema-definition'].value == 'true': false);
  // This limit is how many recursive circular references will be allowed.  Not provided, then use 1, if provided
  // it must be a valid number and if not, use 1.
  var referenceLimit = (swaggerDoc &&
                        swaggerDoc['x-ibm-configuration'] &&
                        swaggerDoc['x-ibm-configuration'].properties &&
                        swaggerDoc['x-ibm-configuration'].properties['x-ibm-gateway-schema-definition-reference-limit']?
                        Number(swaggerDoc['x-ibm-configuration'].properties['x-ibm-gateway-schema-definition-reference-limit'].value): 1);
  if (!isFinite(referenceLimit)) {
    referenceLimit = 1;
  }
  return _getSwaggerDefinition(swaggerDoc,defName,processedReferences,definitionOnly,performanceToggle,foundMap,referenceLimit);
}

function _getSwaggerDefinition(swaggerDoc,defName,processedReferences,definitionOnly,performanceToggle,foundMap,referenceLimit) {
  if (!defName || typeof defName !== 'string') {
   dbglog.error('getSwaggerDefinition: invalid reference: ' + defName);
  return undefined;
  }
  var defNameSplit = defName.split('/');
  if (defNameSplit[0] != '#') {
    dbglog.error('getSwaggerDefinition: invalid reference: ' + defName);
    return undefined;
  }
  defNameSplit.shift(); // remove the #
  var definition = swaggerDoc;
  for (var i=0; i<defNameSplit.length; i++) {
    definition = definition[defNameSplit[i]];
    if (!definition) {
      break;
    }
  }
  if (!definition) {
    dbglog.error('getSwaggerDefinition: definition not found: ' + defName);
    return undefined;
  }

  if (performanceToggle) {
    // To be extra safe, use a clone of the definition to avoid contamination of swaggerDoc
    // Contamination could possibly result in undetectable cycles.
    definition = deepClone(definition);
  }

  // definitionOnly defaults to false, so continue processing and resolve the definition references unless
  // this argument is specified as true, in which case just the unresolved definition is returned.
  if (!definitionOnly) {
    // the first call of this function will not provide processedReferences, initialize to an empty array
    if (processedReferences === undefined) {
      processedReferences = {};
    }
    if (foundMap === undefined) {
        foundMap = {};
    }

    // make a new copy of the processedReferences object so the recursive calls pass in just what has
    // been done previously in this hierarchy but the current reference at sibling levels will not
    // be considered a circular reference.
    var thisProcessedReferences = deepClone(processedReferences);

    // DO NOT DELETE any following file system module usage. Leave commented, uncomment ONLY for any instrumented testing
    // var fsOptions = {TTL : 0 , /* number can be 0-86400, 0 ==> don't delete */
    //                  file : "temporary:///getSwaggerDefinition.txt" }; /* file for read/write operations */

    // current definition name not processed yet or we have but not outside of limits of recursion
    if (thisProcessedReferences[defName] === undefined ||
        (thisProcessedReferences[defName] < referenceLimit &&
         thisProcessedReferences[defName] < SCHEMA_CIRCULAR_REFERENCE_MAX)) {
      // add the current definition name to the processed list, first time in list, reference count is one,
      // otherwise increment the current count.
      if (thisProcessedReferences[defName] === undefined) {
        thisProcessedReferences[defName] = 1;
      } else {
        thisProcessedReferences[defName] += 1;
      }

      // fsOptions.data = Object.keys(processedReferences).length + ' ' + (new Date).toISOString() + ' ' + ' ' +defNameSplit[defNameSplit.length -1] + ' Processing started\n';  /* data to write to file */
      // fs.appendFile(fsOptions, function(appendError){});

      // If we have already processed this definition, return it.  This is the performance enhancement, to return
      // a found JSON object instead of stepping through the schema and producing a new deep copy of the same object.
      // This reduces the amount of memory consumed and the cycles to create the schema, but when you have highly
      // circular references in the schema it could produce a schema that is different had the entire set of definitions
      // been traversed.  For example, the $refs follow definitions G,H,I,J,K,G and G is seen to be circular and the processing
      // stops with an object of expanded definitions G,H,I,J,K.  Suppose another definitions references definition K, then
      // the path followed would be K,G,H,I,J and then K is seen as the circular definition.  Finally, since these saved
      // definitions are JSON objects, if the reference object has an embedded circular reference, you need a deep copy of
      // that object, but in testing of large schema definitions that will create a JSON schema object so large that memory
      // consumption issues have been encountered.  The code will thus return an empty object if the saved object encounters
      // a circular reference therein instead of the K,G,H,I,J noted above.
      //
      // Given these concerns, this feature will be controlled by an API property toggle which will enable this feature.  If
      // the toggle is disabled, a full traversal and copy as was previously done will be executed.  If the toggle was enabled
      // and no circular references exist in the schema, this feature will provide a performance benefit to the end user.  In
      // those cases where there are circular references, it would be recommended this feature only be utilized if the schema
      // is so large that performance issues are noted.
      if (foundMap[defName] && performanceToggle) {
        var circularRefList = [];
        // Note that in searching for circular references in the foundMap already processed, a circular reference
        // to this type would have been handled when the foundMap was originally processed, so only look for references
        // as circular if the parent types of this reference are found within the expanded schema object.  Thus the
        // original processedReferences object is passed here which would not have the current type.
        var foundClone = deepClone(foundMap[defName], processedReferences, circularRefList);

        // fsOptions.data = Object.keys(processedReferences).length + ' ' + (new Date).toISOString() + ' ' + ' ' +defNameSplit[defNameSplit.length -1] + ' circular references ' + circularRefList.toString() + ' Processing completed foundMap[defName]\n';  /* data to write to file */
        // fs.appendFile(fsOptions, function(appendError){});

        // if a circular object reference was found in the deepClone, we will return an empty object for this reference,
        // otherwise we can return a JSON reference to the object and save memory consumption and increase function
        // performance.
        if (circularRefList.length > 0) {
          //return foundClone; // we can't do this as it would increase the memory footprint and cause huge latencies.
          return {};
        } else {
          return foundMap[defName];
        }
      } else {
        // The saved reference wasn't found or the performance toggle was disabled, so traverse this definition to expand
        // any child definitions with their own $ref properties. The result will be saved in the foundMap table for
        // potential subsequent use.
        foundMap[defName] = traverseSwaggerDefinition(swaggerDoc, definition, thisProcessedReferences, performanceToggle, foundMap, referenceLimit);

        // fsOptions.data = Object.keys(processedReferences).length + ' ' + (new Date).toISOString() + ' ' + ' ' +defNameSplit[defNameSplit.length -1] + ' Processing completed traverseSwaggerDefinition\n';  /* data to write to file */
        // fs.appendFile(fsOptions, function(appendError){});

        // a circular reference must return a deep clone of the object so the original reference will consist of all
        // unique objects with no javascript object references that could cause an infinite loop when processing.
        if (thisProcessedReferences[defName] !== 1) {
          return deepClone(foundMap[defName]);
        } else {
          // the original (or only) reference will return the schema definition from the table.  This would include the
          // multiple circular references (cloned objects) that were recursively generated.
          return foundMap[defName];
        }
      }
    } else {
      // circular definition beyond the reference limit is ignored and an empty object is returned.
      dbglog.warn('getSwaggerDefinition: circular definition beyond recursion limit of ' + (referenceLimit < SCHEMA_CIRCULAR_REFERENCE_MAX? referenceLimit : SCHEMA_CIRCULAR_REFERENCE_MAX ) + ' is ignored: ' + defName);

      // fsOptions.data = Object.keys(processedReferences).length + ' ' + (new Date).toISOString() + ' ' + ' ' +defNameSplit[defNameSplit.length -1] + ' Processing completed circular definition ignored\n';  /* data to write to file */
      // fs.appendFile(fsOptions, function(appendError){});

      return {};
    }
  } else {
    // definition only boolean is specified, so just return the raw definition
    return definition;
  }
}

function traverseSwaggerDefinition(swaggerDoc,object,processedReferences,performanceToggle,foundMap,referenceLimit) {
  // Iterate through the keys of the current definition object
  var keys = Object.keys(object);
  var keysLen = keys.length;
  for (var index = 0; index < keysLen; index++) {
    var i = keys[index];
    if (object.hasOwnProperty(i)) {
      // If this object has a reference, get the definition for that $ref and place it into the current object.
      // The $ref is then deleted as we don't want to repeat traversing this definition again, but we will save
      // this reference value in another property as a bread crumb to use for searching for circular object references
      // when a saved copy of this expanded object is used.
      if (i === '$ref') {
        var newobj = _getSwaggerDefinition(swaggerDoc,object[i],processedReferences,false,performanceToggle,foundMap,referenceLimit);
        for (var j in newobj) {
          if (newobj.hasOwnProperty(j)) {
            object[j] = newobj[j];
          }
        }
        object['$$ref$$'] = object[i];
        delete object[i];
      }
      // no $ref for the current property, so traverse any Array and object looking for additional $refs that need to be
      // resolved.  Other types are left asis.
      else if (object[i] !== undefined && object[i] !== null && typeof object[i] === 'object') {
        if (object[i].constructor !== Array) {
          // object, not an array, traverse over the object
          object[i] = traverseSwaggerDefinition(swaggerDoc,object[i],processedReferences,performanceToggle,foundMap,referenceLimit);
        } else {
          // an array, traverse over each array element
          for (var j=0; j<object[i].length; j++) {
            var item = object[i][j];
            // Only process the array item if it is an object
            // (for example, an array is often a required or enum list that would be an array of a primitive)
            // Aside: we could probably also check for the constructor not an array...but we don't
            // have any array of array items in a swagger definition
            if (item !== undefined && item !== null && typeof item === 'object') {
              object[i][j] = traverseSwaggerDefinition(swaggerDoc,item,processedReferences,performanceToggle,foundMap,referenceLimit);
            }
          }
        }
      }
    }
  }
  return object;
}

/**
* @return a deep clone of obj
* the processedReferences and circularRefList are used to determine if a saved object being cloned would contain a definition
* that is circular given the current reference stack.
*/
function deepClone(obj, processedReferences, circularRefList) {
    if (obj === null) {
      return null;
    }
    if (typeof obj !== 'object') {
      return obj;
    }
    var child, cloned;
    if (obj instanceof Array) {
      child = [];
      var len = obj.length;
      for (var i = 0; i < len; i++) {
        cloned = deepClone(obj[i], processedReferences, circularRefList);
        child.push(cloned);
      } // end for
    } else {
      child = {};
      // if this object has a processed reference we need to check if that reference is in the processed reference
      // object (if provided).  If so we have a circular object reference and should not deep clone this object, but
      // instead add the reference to the circular reference list.  An empty object would be returned instead.
      if (obj['$$ref$$'] && processedReferences && circularRefList && processedReferences[obj['$$ref$$']]) {
        circularRefList.push(obj['$$ref$$']);
      } else {
        for (var key in obj) {
          if (obj.hasOwnProperty(key)) {
            cloned = deepClone(obj[key], processedReferences, circularRefList);
            // save the cloned object into the current child object.  Note that in DataPower 7.6.0.x, primitive
            // objects are not allowed to be modified, so attempting to add an key to an object where the key
            // has a value of "toString" for example will fail.  In only those cases, we'll catch the exception
            // thrown and will save the cloned object using the Object.defineProperty function.
            try {
              child[key] = cloned;
            } catch (error) {
              Object.defineProperty(child, key, {value: cloned, writable: true, enumerable: true, configurable: true});
            }
          }
        } // end for
      }
    }
    return child;
}

exports.getSwaggerDefinition = getSwaggerDefinition;

exports.getManagedObject = getManagedObject;

function getManagedObject(options, type) {

  var id = options.id || null;
  var name = options.name || null;
  var version = options.version || null;
  var inProperty = options.property || null;
  var inType = type || null;
  var asFilename = options.asFilename || null;
  var asObject = options.asObject || null;

  var _apimgmt = session.name('_apimgmt');
  if (!_apimgmt) {
    dbglog.error('getTLSProfileObjName: _apimgmt session missing.');
    return undefined;
  }

  var managedObjectsMap = _apimgmt.getVariable('managed-objects');
  var managedObjectsMap = managedObjectsMap.item(0).getElementsByTagName("managed-objects").item(0).lastChild.textContent;

  try{
   managedObjectsMap = JSON.parse(managedObjectsMap);
  }
  catch(err){
    dbglog.err(error.stack);
  }

  var orgId = _apimgmt.getVariable('tenant-orgId');
  var managedObject = undefined;
  var property = undefined

  managedObjectsMap = managedObjectsMap[orgId];
  managedObjectsMap = managedObjectsMap[type];

  if (managedObjectsMap){
    if (name && name.indexOf(':latest') === -1) {
      if (name.indexOf(':') > -1) {
        managedObject = managedObjectsMap['by-nameAndVersion'][name];
      } else {
        // version 1.0.0 is the default version if none is specified
        managedObject = managedObjectsMap['by-nameAndVersion'][name + ':1.0.0'];
        if (managedObject) {
          console.info('managed-object: name:' + name + ' ver:' + managedObject['version'] );
        } else {
          console.error('managed-object: name:' + name + ' ver: 1.0.0 not found');
        }
      }
    }
    if (name && !managedObject && name.indexOf(':latest') > -1) {
      var realname = name.substring(0, name.indexOf(':latest'));
      managedObject = managedObjectsMap['by-name'][realname];
      //TODO Handle exception from failure to sort
      managedObject = managedObject.length > 1 ? managedObject.sort(simpleSymVer) : managedObject;
      managedObject = managedObjectsMap['by-nameAndVersion'][managedObject[managedObject.length - 1]];
      if (managedObject) {
        console.info('managed-object: name:' + name + ' ver:' + managedObject['version'] );
      }
    }
    if (name && version) managedObject = managedObjectsMap['by-nameAndVersion'][name+':'+version];
    if (id && !managedObject) managedObject = managedObjectsMap['by-nameAndVersion'][managedObjectsMap['by-id'][id]];
    if (managedObject && asObject === 'true') {
      console.info('managed-object asObject:' + name + ' (ver:' + managedObject['version'] + ')= ' + inType + '-' + managedObject['id']);
      managedObject = inType + '-' + managedObject['id'];
    }
    if (!managedObject) {
      console.error('managed-object: name:' + name + ' type:' + inType + ' not found');
    }
    if (managedObject && inProperty) {
      if (asFilename === 'true') {
         console.info('managed-object asFileName:' + name + ' (ver:' + managedObject['version'] + ')= ' + inType + '-' + managedObject['id'] + '-' + inProperty);
      }
      managedObject =  (asFilename === 'true') ? (inType + '-' + managedObject['id'] + '-' + inProperty) : managedObject['properties'][inProperty];

      const b64encPrefix = '!BASE64_ENC!_';
      var isString = false;
      if (managedObject) {
        isString = typeof managedObject == 'string';
      }
      if (isString && (managedObject.indexOf(b64encPrefix) !== -1)) {
        const crypto = require('crypto');
        var b64part = managedObject.substring(b64encPrefix.length);

        var buffer = new Buffer(b64part, 'base64');
        var iv = buffer.slice(0,16);
        var payload = buffer.slice(16);

        const decipher = crypto.createDecipheriv('aes256-cbc', 'webapi-oauth-token-ss', iv);
        decipher.update(payload);
        managedObject = String(decipher.final());
      }
    }
  }

  return managedObject;
}

function simpleSymVer(a, b){

  var aVer = a.substring(a.indexOf(':') + 1);
  var bVer = b.substring(b.indexOf(':') + 1);

  try {
    var aVerToks = aVer.split('.');
    var bVerToks = bVer.split('.');
  }
  catch(err){
    console.info("managed-object: version parse error");
    return 0;
  }
  if (aVerToks && bVerToks && (aVerToks.length === bVerToks.length) && (aVerToks > 1)) {
    for (var i = 0; i < aVerToks.length; i++){
      if (aVerToks[i] < bVerToks[i]) {
        console.debug("managed-object: " + a + "<" + b);
        return -1
      }
      if (aVerToks[i] > bVerToks[i]) {
        console.debug("managed-object: " + a + ">" + b);
        return 1;
      }
      continue;
    }
  } else {  //number of dots don't match, fall back to string compare
      if (a < b) {
        console.debug("managed-object: " + a + "<" + b);
        return -1
      }
      if (a > b) {
        console.debug("managed-object: " + a + ">" + b);
        return 1;
      }
  }

  return 0;
}
