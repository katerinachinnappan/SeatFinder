// ***************************************************** {COPYRIGHT-TOP} ***
//* Licensed Materials - Property of IBM
//* 5725-L30, 5725-Z22, 5725-Z63, 5725-U33, 5725-Z63
//*
//* (C) Copyright IBM Corporation 2016, 2017
//*
//* US Government Users Restricted Rights - Use, duplication, or
//* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
// ********************************************************** {COPYRIGHT-END}**
var apim = require('local://isp/policy/apim.custom.js');
var sm = require ('service-metadata');
var hm = require('header-metadata');
var urlopen = require('urlopen');

var verbose = apim.verbose;
var logPrefix = 'getSchema.js: ';

var swaggerLocation = session.name('_apimgmt').getVar('api-swagger');
var policyProperties = apim.getPolicyProperty();

if (swaggerLocation !== undefined) {
	if (verbose)  {
          apim.console.debug(logPrefix+'getSchema.js: swagger location is: '	+ swaggerLocation);
        }
	if (swaggerLocation.length > 0) {
        hm.current.set('X-Target-URL', swaggerLocation + '?type=edge-gateway');
	}
	var headers = hm.current.headers;

	var urlParams = '';
	var protocolMethod = sm.getVar('var://service/protocol-method');

    // We need to determine the path from the api to account for the case of pattern match paths
    // as something like request.path just gives the actual called path and not what the pattern was
    var apiContext = apim.getContext('api');
    var basePath = apiContext.root;
    var apiPath;
    if (basePath !== undefined && basePath.length > 0) {
        apiPath = '/' + basePath + apiContext.operation.path;
    } else {
        apiPath = apiContext.operation.path;
    }

    if (verbose) {
      apim.console.debug(logPrefix+'Method==[' + protocolMethod+'], Path==['+apiPath+']');
    }
    urlParams += '?verb='+protocolMethod.toLowerCase()+'&path='+apiPath;

    var statusCode = session.name('_apimgmt').getVar('last-invoke-status-code');

    var definition = policyProperties.definition;
    if (definition!==undefined) {
    	if (definition.toLowerCase() == 'response') {
    	    urlParams += '&ref='+definition
    	    if (statusCode!==undefined) {
    	    	urlParams += '&status='+statusCode;
    	    }
    	} else if (definition.toLowerCase() == 'request') {
    	    urlParams += '&ref='+definition;
    	} else if (definition.indexOf('#/definitions/')==0) {
    		definition = definition.replace('#/definitions/', '%23/definitions/');
    	    urlParams += '&ref='+definition;
    	}
    }

	var mediaType = session.name('_apimgmt').getVar('policy-output-mediaType');
	if (mediaType===undefined) {
		mediaType=sm.getVar('var://service/original-content-type');
	}
	if (mediaType!==undefined) {
		if (mediaType.indexOf('xml')>=0) {
			urlParams += '&type=XML';
		} else if (mediaType.indexOf('json')>=0) {
			urlParams += '&type=JSON';
		} else {
			//urlParams += '&type=JSON';
		}
	}

    if (verbose) {
      apim.console.debug(logPrefix+'MediaType==[' + mediaType+'], statusCode==['+statusCode+']');
    }

	var v1Gateway = '/cacheJS/v1/catalogs';
	var locv1Gateway = swaggerLocation.indexOf(v1Gateway);
	if (locv1Gateway > 0) {
		var swgPath = swaggerLocation.substring(locv1Gateway + v1Gateway.length);
		var baseUrl = session.name('_apimgmt').getVar('internal-mpgw-url');
		var mpgwUrl = baseUrl + '/schema' + swgPath + urlParams;
		if (verbose) {
                  apim.console.debug(logPrefix+'getSchema.js: mpgw location is: ' + mpgwUrl);
                }
		// replace incoming Accept type to application/json when fetching the swagger/schema document
		headers['Accept']='application/json';
		delete headers['Pragma'];
		var options = {
			target : mpgwUrl,
			method : 'GET',
			timeout : 60,
			headers : headers
		};

		// check in a case insensitve way for the authorization header and delete it from the urlopen headers if present
		var regex = /,(authorization),/i;
		var headerkeys = ',' + Object.keys(headers).toString() + ',';
		var headername = headerkeys.match(regex);
		if (headername && headername[1]) {
		    delete options.headers[headername[1]];
		}

		if (verbose) {
		    apim.console.debug(logPrefix+'getSchema.js: headers used in urlopen: ' +JSON.stringify(headers));
		}

		urlopen.open(options,function(error, response) {
			if (error) {
				apim.console.error(logPrefix+'getSchema.js: URL Open error: ' +JSON.stringify(error));
			} else {
				if (verbose) {
					apim.console.debug(logPrefix+'getSchema.js: response is: '	+ JSON.stringify(response));
				}
				if (response.headers!==undefined && apim.isXML(response.headers['Content-Type'])) {
                    response.readAsXML(function(error, responseData) {
                        if (error) {
                            apim.console.error(logPrefix+'getSchema.js: error reading xml response data: '+ JSON.stringify(error));
                        } else {
                            if (verbose) {
                              apim.console.debug(logPrefix+'getSchema.js: response data: ' + XML.stringify(responseData));
                            }
                            var policyschema = session.name('policyschema') || session.createContext('policyschema');
                            if (policyschema !== undefined) {
                                if (verbose) {
                                  apim.console.debug(logPrefix+'getSchema.js: writing xml to "policyschema" [' + XML.stringify(responseData) + ']');
                                }
                                policyschema.write(XML.stringify(responseData));
                            } else {
                                if (verbose) {
                                  apim.console.debug(logPrefix+'getSchema.js: unable to access context "policyschema"');
                                }
                            }
                        }
                    });
				} else {
				    // read response data
				    response.readAsJSON(function(error,	responseData) {
				        if (error) {
				            apim.console.error(logPrefix+'getSchema.js: error reading json response data: '+ JSON.stringify(error));
				        } else {
				            if (verbose) {
                                              apim.console.debug(logPrefix+'getSchema.js: response data: ' + JSON.stringify(responseData));
                                            }
				            var policyschema = session.name('policyschema') || session.createContext('policyschema');
				            if (policyschema !== undefined) {
				                if (verbose) {
                                                  apim.console.debug(logPrefix+'getSchema.js: writing json to "policyschema" [' + JSON.stringify(responseData) + ']');
                                                }
				                policyschema.write(JSON.stringify(responseData));
				            } else {
				                if (verbose) {
                                                  apim.console.debug(logPrefix+'getSchema.js: unable to access context "policyschema"');
                                                }
				            }
				        }
				    });
				}
			}
		});
        hm.current.remove('X-Target-URL');
	}
}
