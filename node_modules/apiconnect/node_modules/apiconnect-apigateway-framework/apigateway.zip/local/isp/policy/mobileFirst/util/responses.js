// ***************************************************** {COPYRIGHT-TOP} ***
//* Licensed Materials - Property of IBM
//* 5725-L30
//*
//* (C) Copyright IBM Corporation 2016
//*
//* US Government Users Restricted Rights - Use, duplication, or
//* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
// ********************************************************** {COPYRIGHT-END}**


"use strict";

var SecurityLogger = require('local:///isp/policy/mobileFirst/util/security-logger'),
util = require('util');

/**
 * @param reason String describing the reason for rejection.
 * @param info   JSON Object with extra information about the rejection.
 * @param code   should be invalid_request, invalid_token, insufficient_scope etc.
 * @param status The http response code - 200, 400, 401, 403 etc.
 * @param validationCode The validation code - AUTHORIZATION_SUCCESS, AUTHORIZATION_FAILED_MISSING_AUTH_HEADER etc.
 * @param scope  The required scope(s).
 */
function RejectionMessage(reason, info, code, status, validationCode, scope) {
    if (!(this instanceof RejectionMessage)) {
        var message = code?"RejectionMessage ["+code+"]: ":"RejectionMessage: ";
        message += reason;
        
        if (info !== null) {
            if (typeof info === 'object') {
                message += ", " + JSON.stringify(info);
            } else {
                message += ", " + info;
            }
        }
        SecurityLogger.warn(message);
        return new RejectionMessage(reason, info, code, status, validationCode, scope);
    }

    this.reason = reason;
    this.info = info;
    this.code = code;
    this.status = status;
    this.validationCode = validationCode;
    this.scope = scope;
}

util.inherits(RejectionMessage, Error);

exports = module.exports = RejectionMessage;
