// ***************************************************** {COPYRIGHT-TOP} ***
//* Licensed Materials - Property of IBM
//* 5725-L30, 5725-Z22, 5725-Z63, 5725-U33
//*
//* (C) Copyright IBM Corporation 2016, 2017
//*
//* US Government Users Restricted Rights - Use, duplication, or
//* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
// ********************************************************** {COPYRIGHT-END}**
//
var apim = require('local:///isp/policy/apim.custom.js');
var hm = require('header-metadata');

//Remove certain entries from the headers
hm.current.remove('Host');

// read/save request.body
if (apim.getvariable('request.body') !== '') {
  apim.readInput(function(error,data) {
    if (!error) {
      apim.setvariable('request.body', data, 'save');
    }
  });
}
