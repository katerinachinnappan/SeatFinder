// ***************************************************** {COPYRIGHT-TOP} ***
// Licensed Materials - Property of IBM
// 5725-L30, 5725-Z22, 5725-Z63, 5725-U33
//
// (C) Copyright IBM Corporation 2017
//
// US Government Users Restricted Rights - Use, duplication, or
// disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
// ********************************************************** {COPYRIGHT-END}**

var apim = require('local:///isp/policy/apim.custom.js');

var servicemeta = require('service-metadata');

var verbose = apim.verbose;
var apiSession = session.name('api');
var apimgmtSession = session.name('_apimgmt');
var logPrefix = "policy.report.error";


function endWithError(message) {
  if(verbose) {
    apim.console.debug(logPrefix + ": exception-uncaught: " + session.name('policy').getVar('flow/exception-uncaught'));
  }

  var httpCode   = apiSession.getVar('error-protocol-response');
  var httpReason = apiSession.getVar('error-protocol-reason-phrase');
  var errorName  = apiSession.getVar('error-name');
  var errorMessg = apiSession.getVar('error-message');
  var ignorecatch= apiSession.getVar('ignore-catch');
  if(verbose) {
    apim.console.debug('endWithError: HTTP ' + httpCode + ' ' + httpReason);
    apim.console.debug('endWithError: ERRR ' + errorName + ' ' + errorMessg);
    apim.console.debug('endWithError: ignorecatch ' + ignorecatch);
  }

  //@@ if policy didn't set httpCode, check for AAA Authentication failure
  if (!httpCode || httpCode.length === 0) {
    var servicemeta = require('service-metadata'); 
    var svcErrorSubcode = servicemeta.errorSubcode;
    if (verbose) {
      apim.console.debug('endWithError: SUBC ' + svcErrorSubcode);
    }
    if (svcErrorSubcode === '0x01d30001') { // AAA Authentication Failure
      httpCode = '401';
      httpReason = 'Unauthorized';
      errorName  = 'Authentication Failure';
      errorMessg = 'This server could not verify that you are authorized to access the URL';
    }
  }

  //@@ check to see if preflow threw an error, this will activate the catch logic
  //   in the assembly if appropriate
  if (!httpCode || httpCode.length === 0) {
    var preflowError = apimgmtSession.getVar('preflow-error');
    if (preflowError ) {
      if (preflowError === 'BadRequestError') {
        var errors = require('local:///isp/policy/apim.exception.js');
        errorName  = errors.Errors.BadRequestError;
        httpCode = '400';
        httpReason = 'Bad Request';
        errorMessg = '';
      }
    }
  } else {
    // A parse error and a security error or ratelimit error may have happened on the same request.
    // The parse error does not take precedence
    var poJSON = apim.getPolicyDetails();
    var poType = poJSON["@type"];
    if (poType && (poType ==='apim.appidentity' || poType ==='apim.basicauth' || poType ==='apim.oauth' || poType ==='apim.security' || poType ==='apim.ratelimit' )) {
      apimgmtSession.setVar('preflow-error', '');
    }
  }

  //@@ still unknown reason, 500 Internal Server Error it is.
  if (!httpCode || httpCode.length === 0) {
    httpCode = '500';
    httpReason = 'Internal Server Error';
  }

  //@@ do not have a name for this exception?
  if (!errorName|| errorName.length === 0) {
    var errs = require('local:///isp/policy/apim.exception.js'); 
    errorName = errs.Errors.RuntimeError;
  }

  if ((errorMessg === undefined || errorMessg.length === 0) && message.indexOf('xsl:message terminate=yes') === -1) 
  { 
    errorMessg = message;
  }
                      
  if (ignorecatch === undefined)
    ignorecatch = false;

  apim.error(errorName, httpCode, httpReason, errorMessg, ignorecatch);
}

endWithError(servicemeta.errorMessage);
