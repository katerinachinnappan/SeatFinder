// ***************************************************** {COPYRIGHT-TOP} ***
// Licensed Materials - Property of IBM
// 5725-L30, 5725-Z22, 5725-Z63, 5725-U33
//
// (C) Copyright IBM Corporation 2016, 2017
//
// US Government Users Restricted Rights - Use, duplication, or
// disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
// ********************************************************** {COPYRIGHT-END}**

var apim = require('local:///isp/policy/apim.custom.js');
var j2jx = require('local:///isp/policy/json2jsonx.js');

//@@ MAIN
if (session.parameters.action === 'readInputAsJSONX') {
  readInputAsJSONX();
}


//@@ ==========================================================================
//@@ readInputAsJSONX
//@@
//@@
function readInputAsJSONX() {
  apim.readInputAsJSON(function(error,jsonObject) {
    var jsonx;
    if (error) {
      apim.console.error('readInputAsJSONX error: ' + error);
      jsonx = j2jx.transform(error);
    } else {
      if (apim.verbose) {
        apim.console.debug("readInputAsJSONX: input: " + JSON.stringify(jsonObject));
      }
      if (jsonObject!==undefined && JSON.stringify(jsonObject).length > 0 ) {
          jsonx = j2jx.transform(jsonObject);
      }
    }
    if (apim.verbose) {
      apim.console.debug("readInputAsJSONX: output: " + jsonx);
    }
    if (jsonx !== undefined) {
        session.output.write(jsonx);
    }
  });
}
