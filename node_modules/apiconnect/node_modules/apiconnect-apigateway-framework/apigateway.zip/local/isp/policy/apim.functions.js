//***************************************************** {COPYRIGHT-TOP} ***
//* Licensed Materials - Property of IBM
//* 5725-L30, 5725-Z22, 5725-Z63, 5725-U33
//*
//* (C) Copyright IBM Corporation 2016, 2017
//*
//* US Government Users Restricted Rights - Use, duplication, or
//* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
//********************************************************** {COPYRIGHT-END}**


"use strict";

var dbglog = console.options({'category':'apiconnect'});


var lib = {};



lib.isConnectionError = function(message) {
  return !!(message && message.status && message.status.connectionError);
};

lib.isOperationError = function(message) {
  return !!(message && message.status && message.status.operationError);
};

lib.isSOAPError = function(message) {
  return !!(message && message.status && message.status.soapError);
};

lib.isError = function(message) {
  return lib.isConnectionError(message) || lib.isOperationError(message) || lib.isSOAPError(message);
};


module.exports = lib;
