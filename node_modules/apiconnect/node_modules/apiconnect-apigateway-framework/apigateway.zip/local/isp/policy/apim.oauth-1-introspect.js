// ***************************************************** {COPYRIGHT-TOP} ***
//* Licensed Materials - Property of IBM
//* 5725-L30, 5725-Z22, 5725-Z63, 5725-U33
//*
//* (C) Copyright IBM Corporation 2017
//*
//* US Government Users Restricted Rights - Use, duplication, or
//* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
// ********************************************************** {COPYRIGHT-END}**
//
"use strict";

let apim = require('local:///isp/policy/apim.custom.js');
let hm = require('header-metadata');
let urlopen = require('urlopen');

// normalize-space(bearer_token)
let authHeader = hm.current.get('Authorization');
let oauthToken = '';
if (authHeader) {
   oauthToken = authHeader.replace(/^Bearer /g, '');
}

if (oauthToken === '') {
    session.name('api').setVar('error-message', 'Invalid credentials');
    session.name('api').setVar('error-protocol-response', '401');
    session.name('api').setVar('error-protocol-reason-phrase', 'Unauthorized');
    apim.error(errors.Errors.ConnectionError, 401, response.reasonPhrase, 'Invalid or missing credentials');
} else {
    // obtain requried properties
    let endpointURL = decodeURIComponent(session.name('_apimgmt').getVar('introspection-url') || '');
    let tlsProfile = apim.getTLSProfileObjName(session.name('_apimgmt').getVar('introspection-tls-profile') || '');

    if (tlsProfile.substring(0, 7) === 'client:') {
        tlsProfile = tlsProfile.substring(7);
    }

    let scope = '';
    let oauthPol = session.name('_apimgmt').getVariable('oauth/policy').item(0).childNodes;
    if (oauthPol) {
        for (let i = 0; i < oauthPol.length; i++) {
            let node = oauthPol.item(i).nodeName;
            if (node !== undefined && node === 'scopes') {
                scope = oauthPol.item(i).textContent;
                break;
            }
        }
    }

    // setup outgoing (to introspection endpoint) data
    // we're going to pass space delimited scope list
    let form = 'token=' + oauthToken + '&token_type_hint=access_token';
    if (scope !== '') {
        form += '&scope=' + scope;
    }

    // RFC 7662 https://tools.ietf.org/html/rfc7662#section-2.1
    // spells out the content-type
    let options = {
        target: endpointURL,
        method: 'post',
        sslClientProfile: tlsProfile,
        contentType: 'application/x-www-form-urlencoded',
        data: form
    };

    let client_id = session.name('api').getVar('client-id') || '';
    let client_secret = session.name('api').getVar('client-secret') || '';

    if (client_id !== '')  {
        if (client_secret === '') {
            options.data = form + '&client_id=' + client_id;
        }
        else {
            let bah = 'Basic ' + new Buffer(client_id + ':' + client_secret).toString('base64');
            options.headers = {'Authorization' : bah};
        }
    }

    let headers = hm.current.get();

    for (let key in headers) {
        if (headers.hasOwnProperty(key) &&
            (key.toLowerCase()).startsWith('x-introspect-')) {
            if (key.toLowerCase() === 'x-introspect-basic-authorization-header') {

                let inazheader = headers[key];
                if (options.headers === undefined)
                    options.headers = {};

                if (inazheader.indexOf(':') > -1)
                    options.headers['Authorization'] = "Basic " + new Buffer(inazheader).toString('base64');
                else
                    options.headers['Authorization'] = "Basic " + inazheader;
            }
            else if (options.headers !== undefined) {
                let namel = [key];
                options.headers[namel] = headers[key];
            }
            else {
                options.headers = {[key] : headers[key]};
            }
        }
    }

    // all set; make the call
    urlopen.open(options, function(error, response) {
        let errors = require('local:///isp/policy/apim.exception.js');
        if (error) {
            // failed to connect to endpoint
            // raise connection error
            session.name('api').setVar('error-message', 'Failed to connect to introspection endpoint');
            session.name('api').setVar('error-protocol-response', '401');
            session.name('api').setVar('error-protocol-reason-phrase', 'Unauthorized');
            apim.error(errors.Errors.ConnectionError, response.statusCode, response.reasonPhrase, 'Failed to connect to introspection endpoint');
        } 
        else if (response.statusCode !== 200) {
            let errmsg = 'Introspect endpoint returns non-200 error, ' + response.statusCode;
            session.name('api').setVar('error-message', 'Token is invalid');
            session.name('api').setVar('error-protocol-response', '401');
            session.name('api').setVar('error-protocol-reason-phrase', 'Unauthorized');
            apim.error(errors.Errors.ConnectionError, 401, response.reasonPhrase, errmsg);
        }
        else {  // response.statusCode === 200
            // NOTE: we received HTTP 200 indicating that the
            // connection to the endpoint was successful, however,
            // the token state could be inactive.
            response.readAsJSON(function (error, jsonData) {

                if (error) {
                    session.name('api').setVar('error-message', 'Wrong response format from introspect');
                    session.name('api').setVar('error-protocol-response', '401');
                    session.name('api').setVar('error-protocol-reason-phrase', 'Unauthorized');
                    apim.error(errors.Errors.ConnectionError, 401, 'Internal Server Error', 'Wrong response format from introspect');
                }
                else {
                    session.name('_apimgmt').setVar('oauth/introspect/response', jsonData);

                    if (jsonData.active === undefined || jsonData.active !== true) {
                        session.name('api').setVar('error-message', 'Token is not active');
                        session.name('api').setVar('error-protocol-response', '401');
                        session.name('api').setVar('error-protocol-reason-phrase', 'Unauthorized');
                        apim.error(errors.Errors.RuntimeError, 401, 'Internal Server Error', 'Token is not active');
                    }
                    else {
                        // put the output in the format for context variable further on
                        let apimutil = require('local:///isp/apim.util.js');
                        let introspectXml = '<introspect><response>' + apimutil.escapeXML(JSON.stringify(jsonData)) + '</response>';
                        for (let key in jsonData) {
                            if (jsonData.hasOwnProperty(key)) {
                                introspectXml += '<' + apimutil.escapeXML(key) + '>' +
                                                 apimutil.escapeXML(jsonData[key]) + '</' +
                                                 apimutil.escapeXML(key) + '>';
                            }
                        }
                        introspectXml += "</introspect>";
                        session.name('_apimgmt').setVar('oauth/introspect/xmlresponse', introspectXml);

                        // is there any advanced scope check or even scope on APIc that we need to verify against ?
                        let advOrigScope = (session.name('_apimgmt').getVar('introspect-advanced-scope') || '{}');
                        let advScope = JSON.parse(advOrigScope);
                        let verified = true;

                        // extra code to handle the scope  if there is a defined one
                        if (jsonData.scope !== undefined) {
                            if (advScope.scopes !== undefined) {
                                let chkscope = " " + jsonData.scope + " ";
                                for (let i = 0; i < advScope.scopes.length; i++) {
                                    let musthavescope = " " + advScope.scopes[i] + " ";
                                    if (chkscope.indexOf(musthavescope) === -1) {
                                        verified = false;
                                        session.name('api').setVar('error-message', 'Scope not supported by 3rd party');
                                        session.name('api').setVar('error-protocol-response', '401');
                                        session.name('api').setVar('error-protocol-reason-phrase', 'Unauthorized');
                                        apim.error(errors.Errors.ConnectionError, 401, 'Internal Server Error', 'Scope not suppoted by 3rd party');
                                        break;
                                    }
                                }
                            }

                            if (verified === true && 
                                advScope['scope-validate'] !== undefined &&
                                advScope['scope-validate'].url !== undefined) {
                                // same logic is in sts-oauth-scope-check.xsl
                                let servicemeta = require('service-metadata');
                                let body = {};

                                body["context-root"] = session.name('api').getVar('request-context-root');
                                body["resource"] = session.name('api').getVar('request-resource-in-uri');
                                body["method"] = servicemeta.protocolMethod;
                                body["api-scope-required"] = scope;
                                body["access_token"] = jsonData;

                                let scopeurl = decodeURIComponent(advScope['scope-validate'].url || '');
                                let scopetls = apim.getTLSProfileObjName(advScope['scope-validate']['tls-profile'] || '');

                                if (scopeurl === undefined || scopetls === undefined) {
                                    session.name('api').setVar('error-message', 'Failure to setup scope validate endpoint');
                                    session.name('api').setVar('error-protocol-response', '401');
                                    session.name('api').setVar('error-protocol-reason-phrase', 'Unauthorized');
                                    apim.error(errors.Errors.ConnectionError, 401, 'Internal Server Error', 
                                               'Failure to setup scope validate endpoint');
                                }
                                else {
                                    if (scopetls.substring(0, 7) === 'client:') {
                                        scopetls = scopetls.substring(7);
                                    }
                                    let validateoptions = {
                                        target: scopeurl,
                                        method: 'post',
                                        headers: {"X-Global-Transaction-ID": servicemeta.getVar('var://service/transaction-id')},
                                        sslClientProfile: scopetls,
                                        contentType: 'application/json',
                                        data: body
                                    };

                                    // all set; make the call
                                    urlopen.open(validateoptions, function(error, response) {
                                        if (error) {
                                            // failed to connect to endpoint
                                            // raise connection error
                                            session.name('api').setVar('error-message', 'Failed to connect to scope validate endpoint');
                                            session.name('api').setVar('error-protocol-response', '401');
                                            session.name('api').setVar('error-protocol-reason-phrase', 'Unauthorized');
                                            apim.error(errors.Errors.ConnectionError, response.statusCode, 
                                                       response.reasonPhrase, 'Failed to connect to scope validate endpoint');
                                        }
                                        else if (response.statusCode !== 200) {
                                            session.name('api').setVar('error-message', 'advanced scope validation rejects the access');
                                            session.name('api').setVar('error-protocol-response', '401');
                                            session.name('api').setVar('error-protocol-reason-phrase', 'Unauthorized');
                                            apim.error(errors.Errors.RuntimeError, 401, 'Internal Server Error', 
                                                       'advanced scope validation rejects the access');
                                        }
                                        else {
                                            let advscopeXml = '';
                                            for (let key in response.headers) {
                                                if (response.headers.hasOwnProperty(key) &&
                                                    (key.toLowerCase()).startsWith('x-')) {
                                                    advscopeXml += '<' + apimutil.escapeXML(key) + '>' +
                                                                   apimutil.escapeXML(response.headers[key]) + '</' +
                                                                   apimutil.escapeXML(key) + '>';
                                                }
                                            }
                                            if (advscopeXml !== '') {
                                                advscopeXml = '<advanced-consent>' + advscopeXml + '</advanced-consent>';
                                                session.name('_apimgmt').setVar('oauth/advanced-consent', advscopeXml);
                                            }

                                        }
                                    });
                                }
                            }   // advanced scope validate url call
                        }   // all advanced scope check
                    }
                }
            });
        }
    });
}
