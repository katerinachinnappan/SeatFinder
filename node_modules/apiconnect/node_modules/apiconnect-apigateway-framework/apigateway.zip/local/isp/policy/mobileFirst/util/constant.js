// ***************************************************** {COPYRIGHT-TOP} ***
//* Licensed Materials - Property of IBM
//* 5725-L30
//*
//* (C) Copyright IBM Corporation 2016
//*
//* US Government Users Restricted Rights - Use, duplication, or
//* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
// ********************************************************** {COPYRIGHT-END}**

var Constant = {}

Constant.TRACKING_ID_HEADER = "x-wl-analytics-tracking-id";
Constant.HOST = "host";
Constant.COLON = ":";
Constant.DOUBLEFWDSLASH = "//";
Constant.ANALYTICS_EVENT_TYPE = 'NetworkTransaction';

// Strategy names
Constant.MFP_STRATEGY_DEFAULT = 'mobilefirst-strategy';


Constant.TOKEN_URL_SUFFIX = 'api/az/v1/token';
Constant.INTROSPECTION_URL_SUFFIX = 'api/az/v1/introspection';

// Reasons for failed
Constant.CONNECTION_REFUSED = 'Connection refused to ';
Constant.CONNECTION_TIMED_OUT = 'Connection is timed out to ';
Constant.CONNECTION_CERT = 'A certificate is required for connecting to';
Constant.CONNECTION_ERROR = 'An error occurred when trying to connect to ';

Constant.CONF_CLIENT_NOT_DEFINED = 'The confidential client is not defined in MFP server';
Constant.CONF_CLIENT_INVALID_SCOPE = 'The defined confidential client\'s scope in MFP server is invalid';
Constant.BAD_REQUEST = 'The request is bad';
Constant.FAILED_TO_OBTAIN_CONF_CLIENT_TOKEN = 'Failed to obtain confidential client token';

Constant.UNAUTHORIZED_TO_INTROSPECT = 'Unauthorized to introspect';
Constant.UNAUTHORIZED_TO_INTROSPECT_REASON = 'perhaps the confidential client has become invalid - get a new token';

Constant.AUTHORIZATION_FAILED_MFP_SERVER_CONFLICT_RESPONSE = 'MFP Server Conflict response';
Constant.AUTHORIZATION_FAILED_MFP_SERVER_CONFLICT_RESPONSE_REASON = 'The application resent the original request';


// OAuth2 codes
Constant.AUTHORIZATION_BEARER = "Bearer";
Constant.AUTHORIZATION_FAILED_MISSING_AUTHORIZATION = 'missing_authorization';
Constant.AUTHORIZATION_FAILED_INVALID_CLIENT = 'invalid_client';
Constant.AUTHORIZATION_FAILED_INVALID_REQUEST = 'invalid_request';
Constant.AUTHORIZATION_FAILED_INVALID_TOKEN = 'invalid_token';
Constant.AUTHORIZATION_FAILED_INVALID_SCOPE = 'invalid_scope';
Constant.AUTHORIZATION_FAILED_INSUFFICIENT_SCOPE = 'insufficient_scope';
Constant.AUTHORIZATION_FAILED_INTERNAL_SERVER_ERROR = 'server_error';

// OAuth2 Bearer error of server_error
Constant.AUTHORIZATION_FAILED_INTERNAL_SERVER_ERROR_BEARER = 'Bearer  error="server_error"';

// Introspection's response
Constant.SCOPE = 'scope';
Constant.ACTIVE = 'active';
Constant.CLIENT_ID = 'client_id';
Constant.EXP = 'exp';
Constant.USERNAME = 'username';
Constant.MFP_APPLICATION = 'mfp-application';
Constant.MFP_DEVICE = 'mfp-device';
Constant.MFP_USER = 'mfp-user';
Constant.MFP_CHECKS = 'mfp-checks';

// 409 response
Constant.CONFLICT_HEADER = 'MFP-Conflict';

exports = module.exports = Constant;