// ***************************************************** {COPYRIGHT-TOP} ***
// Licensed Materials - Property of IBM
// 5725-L30, 5725-Z22, 5725-Z63, 5725-U33
//
// (C) Copyright IBM Corporation 2016, 2017
//
// US Government Users Restricted Rights - Use, duplication, or
// disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
// ********************************************************** {COPYRIGHT-END}**
var custom = require('local:///isp/policy/apim.custom.js');
var verbose = custom.debug;

session.input.readAsXML(function (error, NodeList) {
  if (error) {
    // handle error
    console.error("Error calling xslt-to-js-bridge");
  }
  else {
    var funcName = NodeList.item(0).textContent;
    var args = NodeList.item(1).textContent;

    switch(funcName){
      //@@ The idea here is that this will be generalized as we go
      //@@ as an enry point to js
      case 'getManagedObject':
        var argsArr = JSON.parse(args);
        if (verbose) custom.console.debug("bridge: case[getManagedObject]");
        executeFunction(funcName, argsArr[0], argsArr[1]);
        break;
      case 'getManagedObjectName':
        var argsArr = JSON.parse(args);
        if (verbose) custom.console.debug("bridge: case[getManagedObjectName]");
        executeFunction(funcName, argsArr[0], argsArr[1]);
        break;
      default:
        if (verbose) custom.console.debug("bridge: case[default]");
        executeFunction(funcName, args);
        break;
    }
  }
});

function executeFunction(funcName, args){
  var retVal = custom[funcName].apply(undefined, Array.prototype.slice.call(arguments, 1));
  if (verbose) custom.console.debug("bridge: retVal["+retVal+"]");
  session.output.write(retVal);
}
