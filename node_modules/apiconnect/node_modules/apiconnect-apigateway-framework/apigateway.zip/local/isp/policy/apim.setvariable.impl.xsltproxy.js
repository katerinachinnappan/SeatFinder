// ***************************************************** {COPYRIGHT-TOP} ***
//* Licensed Materials - Property of IBM
//* 5725-L30, 5725-Z22, 5725-Z63, 5725-U33
//*
//* (C) Copyright IBM Corporation 2018
//*
//* US Government Users Restricted Rights - Use, duplication, or
//* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
// ********************************************************** {COPYRIGHT-END}**
//
// This is a helper GatewayScript which just calls the GatewayScript
// implementation of the getvariable and setvariable functions from an XSLT context

var setVarImpl = require('local:///isp/policy/apim.setvariable.impl.js');
var operation = session.parameters.operation;
var varName = session.parameters.varName;
var varValue = undefined;
switch (operation) {
case 'setvariable':
  if (varName !== undefined) {
    var action = session.parameters.action;
    varValue = session.parameters.varValue;
    var setResult = setVarImpl.setvariable(varName, varValue, action);
    if (setResult) {
      session.output.write('OK');
    } else {
      session.output.write('Failed')
    }
  }
  break;
case 'getvariable':
default:
  varValue = varName !== undefined ? setVarImpl.getvariable(varName) : "";
  session.output.write(varValue);
  break;
}
