/**
 * Licensed Materials - Property of IBM
 * IBM WebSphere DataPower Appliances
   5725-Z22, 5725-Z63, 5725-U33, 5725-Z63

 * (C) Copyright IBM Corporation 2016, 2017.

 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/**
 * @brief Will validate a JSON Web Token
 *        @parm jwt  String: Variable name within which jwt can be found
 *                   default: request.headers.authorization
 *                   note: can be context or runtime variable name
 *                   note: will strip "Bearer " from string
 *                   note: nodelist type blob is only one supported
 *        @parm output-claims String: Variable name to which the JSON set of
 *                                    all claims returned from the JWT
 *                                    verify step will be assigned     If not
 *                                    set an HTTP return 200 = success
 *        @parm iss-claim  PCRE used to verify the issuer claim
 *        @parm aud-claim  PCRE used to verify the Audience claim
 * For jwt-validate 1.0.0
 *		  @parm jws-crypto String: Crypto object to verify JWT
 *        @parm jws-jwk String: Variable name within which a jwk to verify the
 *                              JWT can be found
 *		  @parm jwe-crypto String: Crypto object to decrypt JWT
 *        @parm jwe-jwk String: Variable name within which a jwk to decrypt the
 *                              JWT can be found
 * For jwt-validate 1.0.1
 *        @parm jwe-obj String: Type/name:version of managed object to use for decrypt JWT
 *                              example: private-key/my-key:1.0.0
 *	      @parm jws-obj String: Type/name:version of managed object to use for verify JWT
 *                              example: public-key/my-cert:1.0.0
 */

var jwt = require('jwt'),
  apic = require('local:///isp/policy/apim.custom.js'),
  util = require('util'),
  dbglog = apic.console,
  verbose = apic.verbose,
  logPrefix = 'jwt-validate: ';

var policyProperties = apic.getPolicyProperty();

try {

  if (verbose) {
    dbglog.debug(logPrefix + "Policy properties [" + JSON.stringify(policyProperties) + "]");
  }

  var jwtToken = undefined;

  var authNode = apic.getContext(policyProperties['jwt']);
  if (authNode === undefined)
    authNode = apic.getvariable(policyProperties['jwt']);
  if (authNode) {
    var authHeader = undefined;
    var authNodeType = util.safeTypeOf(authNode);
    switch (authNodeType) {
      case 'node':
        authHeader = XML.stringify({
          omitXmlDeclaration: true
        }, authNode);
        if (authHeader === undefined)
          authHeader = JSON.stringify(authNode);
        break;
      case 'string':
        authHeader = authNode;
        break;
      case 'nodelist':
        var blob = authNode.item(0);
        if (blob.nodeValue !== "***BINARY NODE***" ||
          blob.nodeType !== Node.BLOB_NODE)
          throw ('Error -- JWT Invalid Format: ' + authNodeType);
        var buffer = blob.toBuffer();
        var authHeader = buffer.toString();
        break;
      default:
        throw ('Error -- JWT Invalid Format: ' + authNodeType);
        break;
    }

    jwtToken = authHeader.replace(/^Bearer /g, '');
    if (verbose) {
      dbglog.debug(logPrefix + "JWT Token: " + jwtToken);
    }
  } else {
    throw ('Error -- JWT undefined');
  }

  var decoder = new jwt.Decoder(jwtToken);

  if (policyProperties['jwe-obj']) {
    var isJWK = getMOProperty('jwe-obj', 'isJWK');
    var jweObj;
    if (isJWK && isJWK === true) {
      jweObj = JSON.parse(getMOFileContents('jwe-obj').toString());
    } else {
      jweObj = getMONameDP('jwe-obj');
    }

    decoder.addOperation('decrypt', jweObj);
  } else if (policyProperties['jwe-crypto']) {
    decoder.addOperation('decrypt', policyProperties['jwe-crypto']);
  } else {
    if (policyProperties['jwe-jwk']) {
      var jsonString = apic.getvariable(policyProperties['jwe-jwk']);
      try {
        var jweJWK = JSON.parse(jsonString);
        decoder.addOperation('decrypt', jweJWK);
      } catch (e) {
        throw ('Error -- JWK is not in valid JSON format');
      }
    }
  }

  if (policyProperties['jws-obj']) {

    var isJWK = getMOProperty('jws-obj', 'isJWK');
    var jwsObj;
    if (isJWK && isJWK === true) {
      jwsObj = JSON.parse(getMOFileContents('jws-obj').toString());
    } else {
      jwsObj = getMONameDP('jws-obj');
    }
    decoder.addOperation('verify', jwsObj);

  } else if (policyProperties['jws-crypto']) {
    decoder.addOperation('verify', policyProperties['jws-crypto']);
  } else {
    if (policyProperties['jws-jwk']) {
      var jsonString = apic.getvariable(policyProperties['jws-jwk']);
      try {
        var jwsJWK = JSON.parse(jsonString);
        decoder.addOperation('verify', jwsJWK);
      } catch (e) {
        throw ('Error -- JWK is not in valid JSON format');
      }
    }
  }

  //Claims to be validated

  // By default only expiration and notbefore are validated
  decoder.addOperation({
    "validateDataType": false,
    "validateAudience": false,
    "validateExpiration": true,
    "validateNotBefore": true,
    "validateUsePCRE": false
  }, 'validate');

  var issClaim = policyProperties['iss-claim'];
  if (issClaim) {
    decoder.addOperation({
      "validateDataType": false,
      "validateAudience": false,
      "validateExpiration": false,
      "validateNotBefore": false,
      "validateUsePCRE": true
    }, 'validate', {
      "iss": issClaim
    });
  }

  var audClaim = policyProperties['aud-claim'];
  if (audClaim) {
    decoder.addOperation({
      "validateDataType": false,
      "validateAudience": true,
      "validateExpiration": false,
      "validateNotBefore": false,
      "validateUsePCRE": true
    }, 'validate', {
      "aud": audClaim
    });
  }

  var customClaims = policyProperties['custom-claims'];
  if (customClaims) {
    var jsonString = apic.getvariable(customClaims);
    try {
      // Verify that the custom claims is valid JSON structure
      var claimJSON = JSON.parse(jsonString);
      decoder.addOperation({
        "validateDataType": false,
        "validateAudience": false,
        "validateExpiration": false,
        "validateNotBefore": false,
        "validateUsePCRE": false
      }, 'validate', claimJSON);
    } catch (e) {
      throw ('Error -- Custom Claims not in JSON format');
    }
  }

  var decodedClaims = new Promise(function(resolve, reject) {
    decoder.decode(function(error, claims) {
      if (error) {
        reject(error);
      } else {
        if (verbose) {
          dbglog.debug("Decoded claims: " + JSON.stringify(claims));
        }
        resolve(claims);
      }
    });
  });

  decodedClaims.then(function(result) {
      // Unless an output-claims runtime variable is specified
      // an HTTP return value of 200 is considered indication of a
      // successful validation
      if (policyProperties['output-claims'])
        apic.setvariable(policyProperties['output-claims'], JSON.stringify(result), 'add');
    })
    .catch(function(error) {
      if (error.message) {
        console.error(logPrefix + ":" + error.message);
        session.reject(error.message);
      } else {
        console.error(logPrefix + ":" + error);
        session.reject(error);
      }
    });

} catch (error) {
  if (error.message) {
    console.error(logPrefix + ":" + error.message);
    session.reject(error.message);
  } else {
    console.error(logPrefix + ":" + error);
    session.reject(error);
  }
  return;
}

// Get the file contents of a managed object
function getMOFileContents(propName) {

  var moName = policyProperties[propName];
  var moTokens;
  try {
    moTokens = moName.split('/');
  } catch (err) {
    console.info("managed-object: type parse error");
    throw (e + ' Error -- managed-object: type parse error');
  }

  return new Buffer(apic.getManagedObjectValue(moTokens[0], moTokens[1], 'file'), 'base64');
}

// Get the file contents of a managed object
function getMOProperty(policyPropName, moPropName) {

  var moName = policyProperties[policyPropName];
  var moTokens;
  try {
    moTokens = moName.split('/');
  } catch (err) {
    console.info("managed-object: type parse error");
    throw (e + ' Error -- managed-object: type parse error');
  }

  var options = {
    name: moTokens[1],
    property: moPropName
  };
  return apic.getManagedObjectValue(moTokens[0], moTokens[1], moPropName);
}


// Get the file contents of a managed object
function getMONameDP(propName) {

  var moName = policyProperties[propName];
  var moTokens;
  try {
    moTokens = moName.split('/');
  } catch (err) {
    console.info("managed-object: type parse error");
    throw (e + ' Error -- managed-object: type parse error');
  }

  return apic.getManagedObjectDPName(moTokens[0], moTokens[1]);
}
