// ***************************************************** {COPYRIGHT-TOP} ***
//* Licensed Materials - Property of IBM
//* 5725-L30, 5725-Z22, 5725-Z63, 5725-U33
//*
//* (C) Copyright IBM Corporation 2016, 2017
//*
//* US Government Users Restricted Rights - Use, duplication, or
//* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
// ********************************************************** {COPYRIGHT-END}**

var apim = require('local:///isp/policy/apim.custom.js');
var policy = apim.getPolicyDetails();
var properties = policy.properties;
var verbose = apim.verbose;
var logprefix = 'policy: apim.catch: ';
var exception = session.name('policy').getVariable('flow/exception');

if (verbose) {
  apim.console.debug(logprefix + 'policy details: ' + JSON.stringify(policy));
  apim.console.debug(logprefix + 'exception is ' + (exception === undefined ? exception : JSON.stringify(exception)));
}

var excname = ((exception && exception.name) ? exception.name : '');

if (exception && exception.name && exception.httpReasonPhrase) {
  if (excname === 'runtime.error' && exception.httpReasonPhrase === 'Unauthorized') {
    excname = 'UnauthorizedError';
  } else if (excname === 'runtime.error' && exception.httpReasonPhrase === 'Forbidden')  {
    excname = 'ForbiddenError';
  }
}

var flowAction;

if (exception === undefined)
{
  //TODO skip this catch block, there was no exception before.
  //TODO can check that in api.policy.traverse.xsl
  flowAction = '_SKIP_BLOCK_';
}
else if (exception.scope < policy.depth)
{
  //TODO skip this catch block, this is an inner catch, wrong scope
  //TODO can check that in api.policy.traverse.xsl
  if (verbose) apim.console.debug(logprefix + 'wrong scope');
  flowAction = '_EXCEPTION_';

}
else if (properties !== undefined && properties.errors !== undefined && properties.errors.indexOf(excname) === -1 )
{
  //TODO skip this catch block, this catch is not catching this specific exception
  //TODO can check that in api.policy.traverse.xsl
  if (verbose) apim.console.debug(logprefix + 'exception didnt match');
  flowAction = '_EXCEPTION_';
}
else if (exception.ignorecatch == 'true')
{
  // Exceptions or errors thrown by some policies (security, rate-limit, cors) should not
  // not be caught and are sent back thru the error rule.
  if (verbose) apim.console.debug(logprefix + 'ignoring some non-flow exceptions');
  flowAction = '_SKIP_BLOCK_';
}
else
{

  //This if prevents the following errors from being cauught with 'default'
  if ((excname === 'BadRequestError' ||
      (excname === 'UnauthorizedError') ||
      (excname === 'ForbiddenError')) &&
      (properties === undefined || properties.errors.indexOf(excname) === -1)) {
    if (verbose) apim.console.debug(logprefix + 'exception not specified in properties, skipping block');
    flowAction = '_SKIP_BLOCK_';
  } else {
    //TODO catch exception, run this block
    // properties and properties.errors can be undefined === global handler
    if (verbose) apim.console.debug(logprefix + 'exception match, run block');
    session.name('policy').deleteVariable('flow/exception');
    flowAction = '_DEFAULT_';
  }
}

if (verbose) apim.console.debug(logprefix + 'flowAction: ' + flowAction);
session.name('policy').setVariable('fw/next-policy', flowAction);

