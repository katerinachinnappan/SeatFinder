// ***************************************************** {COPYRIGHT-TOP} ***
// Licensed Materials - Property of IBM
// 5725-L30, 5725-Z22, 5725-Z63, 5725-U33
//
// (C) Copyright IBM Corporation 2016, 2017
//
// US Government Users Restricted Rights - Use, duplication, or
// disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
// ********************************************************** {COPYRIGHT-END}**
var jsonxPrefix = 'jsonx';

exports.transform = function(x, options) {
    // if a string is provided, attempt to parse it to determine if it is
    // an array or object, and if so, the JSONX to be produced is based on
    // the parsed value, not the provided JSON string.
    if ((typeof x === "string") && (x !== null)) {
      var parsed = JSON.parse(x);
      if (isArray(parsed) || (typeof parsed === "object") && (parsed !== null)) {
        x = parsed;
      }
    }
    return traverse(x, options);
}

function traverse(x, options) {
    var level = "";
    var jsonx = "";
    
    if (options!==undefined && options.jsonxPrefix!==undefined) {
        jsonxPrefix = options.jsonxPrefix;
    }

    var jsonxRootAttributes = ' xsi:schemaLocation="http://www.datapower.com/schemas/json jsonx.xsd" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:'+jsonxPrefix+'="http://www.ibm.com/xmlns/prod/2009/jsonx"';

    if (!options || options.xmlprolog) {
        jsonx += '<?xml version="1.0" encoding="UTF-8"?>';
    }
    if (isArray(x)) {
        if (options!==undefined && options.excludeNamespace!==undefined && options.excludeNamespace==true) {
            jsonx += "<"+jsonxPrefix+":array>";
        } else {
            jsonx += "<"+jsonxPrefix+":array" + jsonxRootAttributes + ">";
        }
        jsonx += traverseArray(x, level);
        jsonx += "</"+jsonxPrefix+":array>";
    } else if ((typeof x === "object") && (x !== null)) {
        if (options!==undefined && options.excludeNamespace!==undefined && options.excludeNamespace==true) {
            jsonx += "<"+jsonxPrefix+":object>";
        } else {
            jsonx += "<"+jsonxPrefix+":object" + jsonxRootAttributes + ">";
        }
        jsonx += traverseObject(x, level);
        jsonx += "</"+jsonxPrefix+":object>";
    } else {
        jsonx += traverse2(x, jsonxRootAttributes);
    }
    return jsonx;
}

function traverse2(x, jsonxRootAttributes) {
    if (jsonxRootAttributes === undefined) {
      jsonxRootAttributes = '';
    }
    var jsonx = "";
    if (isArray(x)) {
        jsonx += "<"+jsonxPrefix+":array"+ jsonxRootAttributes +">";
        jsonx += traverseArray(x);
        jsonx += "</"+jsonxPrefix+":array>";
    } else if (typeof x === "object") {
      if (x !== null) {
        jsonx += "<"+jsonxPrefix+":object"+ jsonxRootAttributes +">";
        jsonx += traverseObject(x);
        jsonx += "</"+jsonxPrefix+":object>";
      } else {
        jsonx += "<"+jsonxPrefix+":null"+ jsonxRootAttributes +">" + x + "</"+jsonxPrefix+":null>";
      }
    } else if ((typeof x === "string") && (x !== null)) {
      jsonx += "<"+jsonxPrefix+":string"+ jsonxRootAttributes +">";;
      jsonx += convertChars(x, false);
      jsonx += "</"+jsonxPrefix+":string>";
    } else if (typeof x === "number") {
      jsonx += "<"+jsonxPrefix+":number"+ jsonxRootAttributes +">" + x + "</"+jsonxPrefix+":number>";
    } else if (typeof x === "boolean") {
      jsonx += "<"+jsonxPrefix+":boolean"+ jsonxRootAttributes +">" + x + "</"+jsonxPrefix+":boolean>";
    } else {
        jsonx += "<"+jsonxPrefix+":string"+ jsonxRootAttributes +">" + x + "</"+jsonxPrefix+":string>";
    }
    return jsonx;
}

function isArray(o) {
    return Object.prototype.toString.call(o) === "[object Array]";
}

function traverseArray(arr) {
    var jsonx = "";
    arr.forEach(function(x) {
        jsonx += traverse2(x);
    });
    return jsonx;
}

function traverseObject(obj) {
    var jsonx = "";
    for ( var key in obj) {
        if (obj.hasOwnProperty(key)) {
            if (isArray(obj[key])) {
                jsonx += "<"+jsonxPrefix+":array name=\"" + convertChars(key, true) + "\">";
                jsonx += traverseArray(obj[key]);
                jsonx += "</"+jsonxPrefix+":array>";
            } else if ((typeof obj[key] === "object") && (obj[key] !== null)) {
                jsonx += "<"+jsonxPrefix+":object name=\"" + convertChars(key, true) + "\">"
                jsonx += traverseObject(obj[key]);
                jsonx += "</"+jsonxPrefix+":object>";
            } else {
                jsonx += processValue(key, obj[key]);
            }
        }
    }
    return jsonx;
}

function processValue(key, value) {
    var jsonx = '';
    var valueType = Object.prototype.toString.call(value);
    key = convertChars(key, true);
    if (valueType === "[object String]") {
        value = convertChars(value, false);
        jsonx = "<"+jsonxPrefix+":string name=\"" + key + "\">" + value + "</"+jsonxPrefix+":string>";
    } else if (valueType === "[object Null]") {
        jsonx = "<"+jsonxPrefix+":null name=\"" + key + "\"/>";
    } else if (valueType === "[object Boolean]") {
        jsonx = "<"+jsonxPrefix+":boolean name=\"" + key + "\">" + value + "</"+jsonxPrefix+":boolean>";
    } else if (valueType === "[object Number]") {
        jsonx = "<"+jsonxPrefix+":number name=\"" + key + "\">" + value + "</"+jsonxPrefix+":number>";
    } else {
        jsonx = "<"+jsonxPrefix+":string name=\"" + key + "\">" + value + "</"+jsonxPrefix+":string>";
    }
    return jsonx;
}

function convertChars(value, isName) {
    if (value.indexOf('<?xml') > -1) {
        value = '<![CDATA[' + value + ']]>'
    }
    if (value.indexOf('&') > -1) {
        value = value.replace(/&/g, '&amp;');
    }
    if (value.indexOf('<') > -1) {
        value = value.replace(/</g, '&lt;');
    }
    if (value.indexOf('\"') > -1) {
        if (isName) {
            value = value.replace(/\"/g, '&#34;');
        } else {
            value = value.replace(/\"/g, '"');
        }
    }

// This doesnt work at the moment but not even sure we get unicode values.
// so removing at the moment but leaving the code inplace in case we need to reinstate.    
//    if (value.indexOf('\\u') > -1) {
//        console.log('in unicode check');
//        var regexp1 =  /\u(....)/g;
//        match = regexp1.exec(value);
//        while (match!=null) {
//            console.log('we have a match: '+match[0]+" at index:"+match.index);
//            if (isName) {
//                console.log('updating name');
//                value = value.replace('\\u'+match[0], '&#x'+match[0]+';');
//            } else {
//                console.log('updating value');
//                value = value.replace('\\u'+match[0], String.fromCharCode('0x'+match[0]));
//            }
//            match = regexp1.exec(value);
//        }
//    }

    return value;
}
